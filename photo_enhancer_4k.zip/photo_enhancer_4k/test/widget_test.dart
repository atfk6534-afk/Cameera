import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:photo_enhancer_4k/main.dart';

void main() {
  testWidgets('Home screen shows the pick-photo button', (WidgetTester tester) async {
    await tester.pumpWidget(const PhotoEnhancerApp());

    // شاشة البداية لازم تظهر زرار اختيار الصورة والعنوان الأساسي
    expect(find.text('اختر صورة'), findsOneWidget);
    expect(find.text('4K Photo Enhancer'), findsWidgets);
  });
}
