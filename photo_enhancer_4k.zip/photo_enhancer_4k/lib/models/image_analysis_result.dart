import '../core/constants.dart';

/// نتيجة خطوة "Automatic Image Analysis" في البرومبت.
class ImageAnalysisResult {
  final int width;
  final int height;
  final double blurScore; // كل ما زاد الرقم = الصورة أوضح
  final double noiseScore; // كل ما زاد الرقم = تشويش أكتر
  final double averageBrightness; // 0..255
  final double dynamicRange; // 0..255 (الفرق بين أفتح وأغمق منطقة)
  final ImageQualityClass qualityClass;

  const ImageAnalysisResult({
    required this.width,
    required this.height,
    required this.blurScore,
    required this.noiseScore,
    required this.averageBrightness,
    required this.dynamicRange,
    required this.qualityClass,
  });

  EnhancementProfile get profile => EnhancementProfile.of(qualityClass);

  @override
  String toString() =>
      'ImageAnalysisResult(${width}x$height, blur=${blurScore.toStringAsFixed(1)}, '
      'noise=${noiseScore.toStringAsFixed(1)}, class=$qualityClass)';
}
