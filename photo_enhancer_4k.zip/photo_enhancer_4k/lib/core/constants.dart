/// ثوابت التطبيق — مأخوذة من جدول الـ Quality Classification في البرومبت الأساسي.
library;

class AppConstants {
  AppConstants._();

  /// رابط خدمة التحسين الأونلاين (لمرجعية سريعة فقط — الاستخدام الفعلي
  /// جوه RemoteEnhancementService)
  static const String remoteServiceInfo =
      'Replicate API — https://replicate.com/account/api-tokens';

  /// أقصى طول ضلع في المخرج النهائي (4K target)
  static const int max4kLongSide = 3840;

  /// أقصى طول ضلع مسموح بيه أثناء عمليات المعالجة اليدوية بيكسل-بيكسل
  /// (denoise/sharpen/blend). صور الكاميرا الحديثة ممكن توصل لـ 12-48
  /// ميجابكسل — معالجتها يدويًا بيكسل بيكسل على الحجم الكامل ده بتاخد
  /// دقايق. فبنكبّر/بنصغّر لحد السقف ده الأول (عملية سريعة محسّنة)،
  /// ونعالج على الحجم المضبوط ده بس، وبعدين نكبّر للحجم النهائي (4K)
  /// كخطوة أخيرة سريعة (AI أونلاين أو resize محسّن، مش يدوي).
  static const int maxProcessingLongSide = 1600;

  /// حد أدنى لطول الضلع بعد أي تصغير احترازي (تفادي صور فاضية/تالفة)
  static const int minSafeDimension = 16;
}

/// تصنيف جودة الصورة المدخلة، حسب خطوة "Quality Classification" بالبرومبت.
enum ImageQualityClass { high, medium, low, extremelyLow }

/// كل مستوى جودة له قوة معالجة مختلفة — نفس الجدول بالظبط من البرومبت.
class EnhancementProfile {
  final double enhancementStrength; // 0..1
  final double denoiseStrength; // 0..1
  final double detailRecovery; // 0..1
  final double faceRestoration; // 0..1 (أقل قيمة = حماية أكتر للهوية)

  const EnhancementProfile({
    required this.enhancementStrength,
    required this.denoiseStrength,
    required this.detailRecovery,
    required this.faceRestoration,
  });

  static const Map<ImageQualityClass, EnhancementProfile> table = {
    ImageQualityClass.high: EnhancementProfile(
      enhancementStrength: 0.20,
      denoiseStrength: 0.15,
      detailRecovery: 0.45,
      faceRestoration: 0.10,
    ),
    ImageQualityClass.medium: EnhancementProfile(
      enhancementStrength: 0.45,
      denoiseStrength: 0.40,
      detailRecovery: 0.65,
      faceRestoration: 0.25,
    ),
    ImageQualityClass.low: EnhancementProfile(
      enhancementStrength: 0.70,
      denoiseStrength: 0.60,
      detailRecovery: 0.80,
      faceRestoration: 0.40,
    ),
    ImageQualityClass.extremelyLow: EnhancementProfile(
      // الأولوية هنا: الحفاظ على الهوية > المظهر الطبيعي > توليد تفاصيل
      enhancementStrength: 0.55,
      denoiseStrength: 0.70,
      detailRecovery: 0.55,
      faceRestoration: 0.20,
    ),
  };

  static EnhancementProfile of(ImageQualityClass c) => table[c]!;
}

/// إعدادات المستخدم من شاشة Advanced Settings
enum EnhancementLevel { natural, balanced, strong }

enum FaceProtectionLevel { maximum, high, standard }

enum NoiseReductionLevel { low, medium, high }

enum OutputMode { fourK, originalAspect }

class EnhancementSettings {
  final EnhancementLevel enhancement;
  final FaceProtectionLevel faceProtection;
  final NoiseReductionLevel noiseReduction;
  final OutputMode output;

  const EnhancementSettings({
    this.enhancement = EnhancementLevel.balanced,
    this.faceProtection = FaceProtectionLevel.maximum,
    this.noiseReduction = NoiseReductionLevel.medium,
    this.output = OutputMode.fourK,
  });

  EnhancementSettings copyWith({
    EnhancementLevel? enhancement,
    FaceProtectionLevel? faceProtection,
    NoiseReductionLevel? noiseReduction,
    OutputMode? output,
  }) {
    return EnhancementSettings(
      enhancement: enhancement ?? this.enhancement,
      faceProtection: faceProtection ?? this.faceProtection,
      noiseReduction: noiseReduction ?? this.noiseReduction,
      output: output ?? this.output,
    );
  }

  /// أقصى نسبة تأثير للـ enhancement (باقي النسبة بتتحفظ من الأصلي)
  double get globalEnhancementConfidence {
    switch (enhancement) {
      case EnhancementLevel.natural:
        return 0.45;
      case EnhancementLevel.balanced:
        return 0.65;
      case EnhancementLevel.strong:
        return 0.85;
    }
  }

  /// أقصى نسبة تأثير مسموحة *داخل مناطق الوجوه* تحديدًا (أهم قاعدة حماية)
  double get faceEnhancementConfidenceCap {
    switch (faceProtection) {
      case FaceProtectionLevel.maximum:
        return 0.18;
      case FaceProtectionLevel.high:
        return 0.35;
      case FaceProtectionLevel.standard:
        return 0.55;
    }
  }

  double get denoiseMultiplier {
    switch (noiseReduction) {
      case NoiseReductionLevel.low:
        return 0.5;
      case NoiseReductionLevel.medium:
        return 1.0;
      case NoiseReductionLevel.high:
        return 1.5;
    }
  }
}
