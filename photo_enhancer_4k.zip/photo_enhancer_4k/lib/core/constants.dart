library;

class AppConstants {
  AppConstants._();

  static const String modelAssetPath = 'assets/models/realesr-general-x4v3.onnx';
  static const int tileSize = 96;
  static const int tileOverlap = 12;
  static const int max4kLongSide = 3840;
  static const int minSafeDimension = 16;
}

enum ImageQualityClass { high, medium, low, extremelyLow }

class EnhancementProfile {
  final double enhancementStrength;
  final double denoiseStrength;
  final double detailRecovery;
  final double faceRestoration;

  const EnhancementProfile({
    required this.enhancementStrength,
    required this.denoiseStrength,
    required this.detailRecovery,
    required this.faceRestoration,
  });

  static const Map<ImageQualityClass, EnhancementProfile> table = {
    ImageQualityClass.high: EnhancementProfile(
      enhancementStrength: 0.20,
      denoiseStrength: 0.10,
      detailRecovery: 0.45,
      faceRestoration: 0.10,
    ),
    ImageQualityClass.medium: EnhancementProfile(
      enhancementStrength: 0.40,
      denoiseStrength: 0.25,
      detailRecovery: 0.60,
      faceRestoration: 0.18,
    ),
    ImageQualityClass.low: EnhancementProfile(
      enhancementStrength: 0.60,
      denoiseStrength: 0.40,
      detailRecovery: 0.75,
      faceRestoration: 0.25,
    ),
    ImageQualityClass.extremelyLow: EnhancementProfile(
      enhancementStrength: 0.50,
      denoiseStrength: 0.45,
      detailRecovery: 0.55,
      faceRestoration: 0.20,
    ),
  };

  static EnhancementProfile of(ImageQualityClass c) => table[c]!;
}

enum EnhancementLevel { natural, balanced, strong }
enum FaceProtectionLevel { maximum, high, standard }
enum NoiseReductionLevel { low, medium, high }
enum OutputMode { fourK, originalAspect }

class EnhancementSettings {
  final EnhancementLevel enhancement;
  final FaceProtectionLevel faceProtection;
  final NoiseReductionLevel noiseReduction;
  final OutputMode output;

  const EnhancementSettings({
    this.enhancement = EnhancementLevel.balanced,
    this.faceProtection = FaceProtectionLevel.maximum,
    this.noiseReduction = NoiseReductionLevel.medium,
    this.output = OutputMode.fourK,
  });

  EnhancementSettings copyWith({
    EnhancementLevel? enhancement,
    FaceProtectionLevel? faceProtection,
    NoiseReductionLevel? noiseReduction,
    OutputMode? output,
  }) {
    return EnhancementSettings(
      enhancement: enhancement ?? this.enhancement,
      faceProtection: faceProtection ?? this.faceProtection,
      noiseReduction: noiseReduction ?? this.noiseReduction,
      output: output ?? this.output,
    );
  }

  double get globalEnhancementConfidence {
    switch (enhancement) {
      case EnhancementLevel.natural:
        return 0.42;
      case EnhancementLevel.balanced:
        return 0.62;
      case EnhancementLevel.strong:
        return 0.78;
    }
  }

  double get faceEnhancementConfidenceCap {
    switch (faceProtection) {
      case FaceProtectionLevel.maximum:
        return 0.16;
      case FaceProtectionLevel.high:
        return 0.30;
      case FaceProtectionLevel.standard:
        return 0.48;
    }
  }

  double get denoiseMultiplier {
    switch (noiseReduction) {
      case NoiseReductionLevel.low:
        return 0.45;
      case NoiseReductionLevel.medium:
        return 0.80;
      case NoiseReductionLevel.high:
        return 1.15;
    }
  }
}
