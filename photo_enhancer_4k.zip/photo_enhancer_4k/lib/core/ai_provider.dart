/// المزوّدين المتاحين لخطوة التحسين. الافتراضي (none) بيستخدم فلاتر
/// تلقائية محلية بس (Auto Levels/White Balance/Vibrance/Sharpen) —
/// سريع وموثوق 100% ومحتاجش إنترنت خالص. باقي المزوّدين اختياريين
/// لمين عايز يجرّب Super-Resolution أونلاين (أبطأ وغير مضمون التوفر).
///
/// ملحوظة مهمة: Claude (Anthropic) مالوش API لتوليد أو تعديل الصور —
/// هو نموذج نصوص/محادثة بس، فمش موجود هنا كمحرّك تحسين صور.
enum AiProvider { none, huggingFace, replicate, openAI, gemini }

/// Space افتراضي على Hugging Face لموديل Real-ESRGAN مفتوح المصدر —
/// شغال بدون أي مفتاح شخصي (بحدود استخدام عامة). الـ Spaces المجانية
/// بتتغيّر/بتتوقف أحيانًا (الأصلي doevent/Face-Real-ESRGAN اتوقف مثلاً)،
/// فده قابل للتغيير من الإعدادات لو احتجت تستبدله بـ Space تاني شغال.
const String defaultHuggingFaceSpace = 'Boboiazumi/Face-Real-ESRGAN';

extension AiProviderInfo on AiProvider {
  String get displayName {
    switch (this) {
      case AiProvider.none:
        return 'فلاتر محلية فقط (سريع)';
      case AiProvider.huggingFace:
        return 'Hugging Face (مفتوح المصدر)';
      case AiProvider.replicate:
        return 'Replicate';
      case AiProvider.openAI:
        return 'OpenAI';
      case AiProvider.gemini:
        return 'Google Gemini';
    }
  }

  /// لو true، المزوّد ده ممكن يشتغل من غير مفتاح شخصي.
  bool get worksWithoutKey =>
      this == AiProvider.none || this == AiProvider.huggingFace;

  /// لو true، المزوّد ده بيحتاج نداء شبكة فعلي (يعني ممكن ياخد وقت
  /// وممكن يفشل ويرجع للفلاتر المحلية).
  bool get requiresNetwork => this != AiProvider.none;

  String get keyHint {
    switch (this) {
      case AiProvider.none:
        return 'مفيش مفتاح مطلوب — فلاتر محلية بس، فورية وموثوقة 100%';
      case AiProvider.huggingFace:
        return 'اختياري — hf_xxxxxxxx من huggingface.co/settings/tokens (لرفع حدود الاستخدام بس). ملحوظة: أبطأ وممكن ميرجعش نتيجة أحيانًا.';
      case AiProvider.replicate:
        return 'r8_xxxxxxxx من replicate.com/account/api-tokens';
      case AiProvider.openAI:
        return 'sk-xxxxxxxx من platform.openai.com/api-keys';
      case AiProvider.gemini:
        return 'AIzaSyxxxxxxxx من aistudio.google.com/apikey';
    }
  }
}
