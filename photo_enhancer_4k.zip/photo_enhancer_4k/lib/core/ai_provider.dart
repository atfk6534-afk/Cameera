/// المزوّدين المتاحين لخطوة التحسين الأونلاين (Super-Resolution).
///
/// ملحوظة مهمة: Claude (Anthropic) مالوش API لتوليد أو تعديل الصور —
/// هو نموذج نصوص/محادثة بس، فمش موجود هنا كمحرّك تحسين صور. الخيارات
/// المتاحة هي الشركات/الجهات اللي فعليًا بتقدّم API لمعالجة الصور.
enum AiProvider { huggingFace, replicate, openAI, gemini }

/// Space افتراضي على Hugging Face لموديل Real-ESRGAN مفتوح المصدر —
/// شغال بدون أي مفتاح شخصي (بحدود استخدام عامة). الـ Spaces المجانية
/// بتتغيّر/بتتوقف أحيانًا (الأصلي doevent/Face-Real-ESRGAN اتوقف مثلاً)،
/// فده قابل للتغيير من الإعدادات لو احتجت تستبدله بـ Space تاني شغال.
const String defaultHuggingFaceSpace = 'Boboiazumi/Face-Real-ESRGAN';

extension AiProviderInfo on AiProvider {
  String get displayName {
    switch (this) {
      case AiProvider.huggingFace:
        return 'Hugging Face (مفتوح المصدر)';
      case AiProvider.replicate:
        return 'Replicate';
      case AiProvider.openAI:
        return 'OpenAI';
      case AiProvider.gemini:
        return 'Google Gemini';
    }
  }

  /// لو true، المزوّد ده ممكن يشتغل من غير مفتاح شخصي (بحدود استخدام أقل).
  bool get worksWithoutKey => this == AiProvider.huggingFace;

  String get keyHint {
    switch (this) {
      case AiProvider.huggingFace:
        return 'اختياري — hf_xxxxxxxx من huggingface.co/settings/tokens (لرفع حدود الاستخدام بس)';
      case AiProvider.replicate:
        return 'r8_xxxxxxxx من replicate.com/account/api-tokens';
      case AiProvider.openAI:
        return 'sk-xxxxxxxx من platform.openai.com/api-keys';
      case AiProvider.gemini:
        return 'AIzaSyxxxxxxxx من aistudio.google.com/apikey';
    }
  }
}
