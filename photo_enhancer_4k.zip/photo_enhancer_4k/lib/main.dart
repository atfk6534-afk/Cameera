import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  // WidgetsFlutterBinding مش لازم هنا لأننا مش بنستخدم أي platform channel
  // قبل runApp، بس بنسيبها كتعليق توضيحي لو حد ضاف init logic لاحقًا:
  // WidgetsFlutterBinding.ensureInitialized();
  runApp(const PhotoEnhancerApp());
}

class PhotoEnhancerApp extends StatelessWidget {
  const PhotoEnhancerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '4K Photo Enhancer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
        brightness: Brightness.dark,
      ),
      // دعم العربية كواجهة أساسية للتطبيق
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        // ملحوظة: لو عايز ترجمة تلقائية لعناصر Material/Cupertino بالعربي
        // ضيف flutter_localizations في pubspec وفعّلها هنا (راجع README).
      ],
      home: const HomeScreen(),
    );
  }
}
