import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  // WidgetsFlutterBinding مش لازم هنا لأننا مش بنستخدم أي platform channel
  // قبل runApp، بس بنسيبها كتعليق توضيحي لو حد ضاف init logic لاحقًا:
  // WidgetsFlutterBinding.ensureInitialized();
  runApp(const PhotoEnhancerApp());
}

class PhotoEnhancerApp extends StatelessWidget {
  const PhotoEnhancerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '4K Photo Enhancer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
        brightness: Brightness.dark,
      ),
      // ملحوظة مهمة: من غير flutter_localizations، منسيبش
      // localizationsDelegates فاضية — ده بيلغي الترجمات الافتراضية
      // (GlobalMaterialLocalizations) اللي Flutter بيضيفها تلقائيًا،
      // ويسبب "No MaterialLocalizations found" وقت التشغيل/التستات.
      // النصوص في التطبيق كلها مكتوبة عربي يدويًا داخل الشاشات نفسها،
      // فمش محتاجين حزمة الترجمة دلوقتي — بنسيب Flutter يستخدم
      // الديفولت بتاعه عادي (بنمسح الخاصية دي بالكامل).
      home: const HomeScreen(),
    );
  }
}
