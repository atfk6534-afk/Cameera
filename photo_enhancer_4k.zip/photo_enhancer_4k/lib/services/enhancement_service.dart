import 'dart:math';
import 'package:image/image.dart' as img;

import '../core/constants.dart';
import '../models/image_analysis_result.dart';

/// خطوات "Main Restoration" (denoise/sharpen/auto-enhance) و"Fallback
/// Upscaling" المحلية. كل الدوال هنا Dart خالص (من غير أي موديل AI أو
/// نداء شبكة) — سريعة وآمنة تتنفّذ جوه Isolate منفصل عشان متأثرش على
/// سلاسة واجهة المستخدم. دي المسار الافتراضي للتطبيق (فلاتر تلقائية
/// فورية)، والـ AI الأونلاين بقى اختياري بالكامل من الإعدادات.
class EnhancementService {
  img.Image denoise(img.Image source, double strength) {
    if (strength <= 0.001) return source;
    final radius = (1 + strength * 2).round().clamp(1, 4);
    final blurred = img.gaussianBlur(source, radius: radius);
    return _linearBlend(source, blurred, strength.clamp(0.0, 0.6));
  }

  /// تحسين الألوان التلقائي — 3 خطوات كلاسيكية في باس واحد سريع:
  /// 1) White Balance (Gray World) — بيصحّح أي ميل لوني (احمرار/اصفرار).
  /// 2) Auto Levels — بيمدّد التباين (يعمّق الأسود ويفتّح الأبيض).
  /// 3) Vibrance — بيزوّد التشبع اللوني باعتدال من غير ما يبالغ في
  ///    الألوان اللي أصلاً مشبّعة (عكس الـ saturation العادية).
  img.Image autoEnhanceColor(
    img.Image source, {
    double vibranceAmount = 0.18,
    double levelsClipPercent = 0.5,
  }) {
    final w = source.width, h = source.height;
    final count = w * h;
    if (count == 0) return source;

    double sumR = 0, sumG = 0, sumB = 0;
    final hist = List<int>.filled(256, 0);
    for (final p in source) {
      sumR += p.r;
      sumG += p.g;
      sumB += p.b;
      hist[p.luminance.round().clamp(0, 255)]++;
    }

    final avgR = sumR / count, avgG = sumG / count, avgB = sumB / count;
    final gray = (avgR + avgG + avgB) / 3;
    final wbR = avgR > 1 ? (gray / avgR).clamp(0.85, 1.2) : 1.0;
    final wbG = avgG > 1 ? (gray / avgG).clamp(0.85, 1.2) : 1.0;
    final wbB = avgB > 1 ? (gray / avgB).clamp(0.85, 1.2) : 1.0;

    final clip = (count * levelsClipPercent / 100).round();
    int lo = 0, hi = 255, acc = 0;
    for (int i = 0; i < 256; i++) {
      acc += hist[i];
      if (acc > clip) {
        lo = i;
        break;
      }
    }
    acc = 0;
    for (int i = 255; i >= 0; i--) {
      acc += hist[i];
      if (acc > clip) {
        hi = i;
        break;
      }
    }
    final levelsScale = hi > lo ? 255.0 / (hi - lo) : 1.0;
    final vibFactor = 1.0 + vibranceAmount;

    final result = img.Image.from(source);
    for (int y = 0; y < h; y++) {
      for (int x = 0; x < w; x++) {
        final p = source.getPixel(x, y);

        double r = p.r * wbR, g = p.g * wbG, b = p.b * wbB;

        r = (r - lo) * levelsScale;
        g = (g - lo) * levelsScale;
        b = (b - lo) * levelsScale;
        r = r.clamp(0, 255);
        g = g.clamp(0, 255);
        b = b.clamp(0, 255);

        final luma = 0.299 * r + 0.587 * g + 0.114 * b;
        r = (luma + (r - luma) * vibFactor).clamp(0, 255);
        g = (luma + (g - luma) * vibFactor).clamp(0, 255);
        b = (luma + (b - luma) * vibFactor).clamp(0, 255);

        result.setPixelRgba(x, y, r, g, b, p.a);
      }
    }
    return result;
  }

  img.Image naturalSharpen(img.Image source, double amount) {
    if (amount <= 0.001) return source;
    final blurred = img.gaussianBlur(source, radius: 2);
    final result = img.Image.from(source);
    final a = amount.clamp(0.0, 0.5);

    for (int y = 0; y < source.height; y++) {
      for (int x = 0; x < source.width; x++) {
        final p = source.getPixel(x, y);
        final b = blurred.getPixel(x, y);

        final r = _sharpenChannel(p.r.toDouble(), b.r.toDouble(), a);
        final g = _sharpenChannel(p.g.toDouble(), b.g.toDouble(), a);
        final bChan = _sharpenChannel(p.b.toDouble(), b.b.toDouble(), a);

        result.setPixelRgba(x, y, r, g, bChan, p.a.toInt());
      }
    }
    return result;
  }

  double _sharpenChannel(double original, double blurred, double amount) {
    final v = original + amount * (original - blurred);
    return v.clamp(0, 255);
  }

  img.Image _linearBlend(img.Image a, img.Image b, double tOfB) {
    final result = img.Image.from(a);
    final t = tOfB.clamp(0.0, 1.0);
    for (int y = 0; y < a.height; y++) {
      for (int x = 0; x < a.width; x++) {
        final pa = a.getPixel(x, y);
        final pb = b.getPixel(x, y);
        result.setPixelRgba(
          x,
          y,
          pa.r * (1 - t) + pb.r * t,
          pa.g * (1 - t) + pb.g * t,
          pa.b * (1 - t) + pb.b * t,
          pa.a,
        );
      }
    }
    return result;
  }

  /// تكبير محلي عالي الجودة (Cubic) — بيستخدم لما الخدمة الأونلاين مش
  /// متاحة (مفيش نت / مفيش مفتاح API / فشل النداء).
  img.Image localUpscale(img.Image source, int factor) {
    if (factor <= 1) return source;
    return img.copyResize(
      source,
      width: source.width * factor,
      height: source.height * factor,
      interpolation: img.Interpolation.cubic,
    );
  }

  /// يحسب factor التكبير المطلوب فعليًا للوصول لهدف 4K من غير تكبير زيادة
  /// عن اللازم. بياخد أبعاد صريحة (مش من الصورة الأصلية بالضرورة) عشان
  /// نقدر نحسبه من حجم "working" بعد الـ cap لا من الحجم الأصلي الضخم.
  int computeScaleFactorFor(int width, int height, {int maxScale = 4}) {
    final longSide = max(width, height);
    if (longSide <= 0) return 1;
    final neededScale = AppConstants.max4kLongSide / longSide;
    if (neededScale <= 1.0) return 1;
    return min(maxScale, max(1, neededScale.ceil()));
  }

  /// نفس الحساب لكن ياخد ImageAnalysisResult مباشرة (للتوافق مع الاستخدام
  /// القديم لو احتجناه في مكان تاني).
  int computeScaleFactor(ImageAnalysisResult analysis, {int maxScale = 4}) {
    return computeScaleFactorFor(analysis.width, analysis.height, maxScale: maxScale);
  }

  /// بيصغّر الصورة لو طول ضلعها الأكبر متعدّي السقف المسموح للمعالجة
  /// اليدوية بيكسل-بيكسل (denoise/sharpen/blend) — عشان العمليات دي
  /// تفضل سريعة حتى لو الصورة الأصلية من كاميرا 48 ميجابكسل.
  img.Image capForProcessing(img.Image source, {int? maxLongSide}) {
    final cap = maxLongSide ?? AppConstants.maxProcessingLongSide;
    final longSide = max(source.width, source.height);
    if (longSide <= cap) return source;
    final scale = cap / longSide;
    return img.copyResize(
      source,
      width: (source.width * scale).round(),
      height: (source.height * scale).round(),
      interpolation: img.Interpolation.average,
    );
  }
}
