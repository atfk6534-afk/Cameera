import 'dart:math';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';

import '../core/constants.dart';
import '../models/image_analysis_result.dart';

/// خطوات "Main Restoration" + "Face Restoration (تقني)" + "Final Upscaling"
/// من البرومبت. كل المعالجة بتحصل offline بالكامل: الموديل شغّال محليًا
/// عن طريق tflite_flutter، من غير أي اتصال إنترنت.
class EnhancementService {
  Interpreter? _interpreter;
  bool _modelReady = false;

  /// نحاول نحمّل الموديل مرة واحدة بس. لو الملف مش موجود (المستخدم لسه
  /// مضافش الموديل الحقيقي في assets) بنرجع false بدل ما نكسر التطبيق،
  /// وساعتها الـ pipeline بيكمل بخطوات denoise/sharpen بس من غير SR حقيقي.
  Future<bool> ensureModelLoaded() async {
    if (_modelReady) return true;
    try {
      final options = InterpreterOptions()..threads = 4;
      _interpreter = await Interpreter.fromAsset(
        AppConstants.modelAssetPath,
        options: options,
      );
      _modelReady = true;
      return true;
    } catch (_) {
      _modelReady = false;
      return false;
    }
  }

  void dispose() {
    _interpreter?.close();
    _interpreter = null;
    _modelReady = false;
  }

  // ---------------------------------------------------------------------
  // Step 5: Main Restoration (denoise + deblur تقريبي + sharpen طبيعي)
  // ---------------------------------------------------------------------

  img.Image denoise(img.Image source, double strength) {
    if (strength <= 0.001) return source;
    // Gaussian خفيف + دمج مرجّح بالنسبة المطلوبة فقط، بدل استبدال كامل،
    // عشان منفقدش تفاصيل حقيقية (مطابقة لقاعدة "Do not completely eliminate
    // natural photographic texture" في البرومبت).
    final radius = (1 + strength * 2).round().clamp(1, 4);
    final blurred = img.gaussianBlur(source, radius: radius);
    return _linearBlend(source, blurred, strength.clamp(0.0, 0.6));
  }

  img.Image naturalSharpen(img.Image source, double amount) {
    if (amount <= 0.001) return source;
    // Unsharp mask كلاسيكي: original + amount * (original - blurred)
    // بأمان (clamped) لتفادي halos/ringing المذكورة في الـ negative prompt.
    final blurred = img.gaussianBlur(source, radius: 2);
    final result = img.Image.from(source);
    final a = amount.clamp(0.0, 0.5); // سقف أمان يمنع oversharpening

    for (int y = 0; y < source.height; y++) {
      for (int x = 0; x < source.width; x++) {
        final p = source.getPixel(x, y);
        final b = blurred.getPixel(x, y);

        final r = _sharpenChannel(p.r.toDouble(), b.r.toDouble(), a);
        final g = _sharpenChannel(p.g.toDouble(), b.g.toDouble(), a);
        final bChan = _sharpenChannel(p.b.toDouble(), b.b.toDouble(), a);

        result.setPixelRgba(x, y, r, g, bChan, p.a.toInt());
      }
    }
    return result;
  }

  double _sharpenChannel(double original, double blurred, double amount) {
    final v = original + amount * (original - blurred);
    return v.clamp(0, 255);
  }

  img.Image _linearBlend(img.Image a, img.Image b, double tOfB) {
    final result = img.Image.from(a);
    final t = tOfB.clamp(0.0, 1.0);
    for (int y = 0; y < a.height; y++) {
      for (int x = 0; x < a.width; x++) {
        final pa = a.getPixel(x, y);
        final pb = b.getPixel(x, y);
        result.setPixelRgba(
          x,
          y,
          pa.r * (1 - t) + pb.r * t,
          pa.g * (1 - t) + pb.g * t,
          pa.b * (1 - t) + pb.b * t,
          pa.a,
        );
      }
    }
    return result;
  }

  // ---------------------------------------------------------------------
  // Step 8: Final Upscaling — Tile-based Super Resolution (offline model)
  // ---------------------------------------------------------------------

  /// بيقسم الصورة لتايلات متراكبة، يشغّل الموديل على كل تايل، وبيجمّعهم
  /// تاني بـ feather blending في مناطق التراكب لتفادي الخطوط الظاهرة.
  /// لو الموديل مش متاح (ensureModelLoaded رجعت false) بيستخدم تكبير
  /// تقليدي عالي الجودة (Lanczos) بدل ما يكسّر العملية بالكامل.
  Future<img.Image> superResolve(
    img.Image source, {
    required int modelScaleFactor,
  }) async {
    if (!_modelReady || _interpreter == null) {
      return _fallbackHighQualityUpscale(source, modelScaleFactor);
    }

    const tile = AppConstants.tileSize;
    const overlap = AppConstants.tileOverlap;
    final outW = source.width * modelScaleFactor;
    final outH = source.height * modelScaleFactor;

    final output = img.Image(width: outW, height: outH);
    final weight = Float32List(outW * outH); // تراكم الأوزان لكل بكسل

    for (int ty = 0; ty < source.height; ty += (tile - overlap)) {
      for (int tx = 0; tx < source.width; tx += (tile - overlap)) {
        final x0 = tx;
        final y0 = ty;
        final x1 = min(tx + tile, source.width);
        final y1 = min(ty + tile, source.height);
        final w = x1 - x0;
        final h = y1 - y0;
        if (w <= 0 || h <= 0) continue;

        final tileImg = img.copyCrop(source, x: x0, y: y0, width: w, height: h);
        final padded = _padToSize(tileImg, tile, tile);

        img.Image srTile;
        try {
          srTile = _runModelOnTile(padded, modelScaleFactor);
        } catch (_) {
          // فشل تشغيل الموديل على تايل واحد ميوقفش الصورة كلها —
          // بنرجع لتكبير تقليدي لنفس التايل بس (fail-safe محلي).
          srTile = img.copyResize(
            padded,
            width: tile * modelScaleFactor,
            height: tile * modelScaleFactor,
            interpolation: img.Interpolation.cubic,
          );
        }

        // نقص التايل الناتج لحجم الجزء الحقيقي (شيل الـ padding) بعد التكبير
        final realOutW = w * modelScaleFactor;
        final realOutH = h * modelScaleFactor;
        final cropped = img.copyCrop(
          srTile,
          x: 0,
          y: 0,
          width: min(realOutW, srTile.width),
          height: min(realOutH, srTile.height),
        );

        _blendTileInto(
          output,
          weight,
          cropped,
          offsetX: x0 * modelScaleFactor,
          offsetY: y0 * modelScaleFactor,
          overlapPx: overlap * modelScaleFactor,
        );
      }
    }

    _normalizeByWeight(output, weight);
    return output;
  }

  img.Image _fallbackHighQualityUpscale(img.Image source, int factor) {
    return img.copyResize(
      source,
      width: source.width * factor,
      height: source.height * factor,
      interpolation: img.Interpolation.cubic,
    );
  }

  img.Image _padToSize(img.Image src, int w, int h) {
    if (src.width == w && src.height == h) return src;
    final canvas = img.Image(width: w, height: h);
    img.fill(canvas, color: img.ColorRgb8(0, 0, 0));
    img.compositeImage(canvas, src);
    return canvas;
  }

  /// تحويل التايل لـ tensor، تشغيل الـ interpreter، وتحويل الناتج رجوع لصورة.
  /// الشكل المتوقع هنا هو الأكثر شيوعًا لموديلات SR: input [1,H,W,3] float32
  /// بمدى 0..1، وoutput [1,H*scale,W*scale,3] بنفس المدى.
  /// لو موديلك شكله مختلف، عدّل الدالة دي بس — باقي الـ pipeline مش هيتأثر.
  img.Image _runModelOnTile(img.Image tile, int scale) {
    final interpreter = _interpreter!;
    final w = tile.width;
    final h = tile.height;

    final input = List.generate(
      1,
      (_) => List.generate(
        h,
        (y) => List.generate(
          w,
          (x) {
            final p = tile.getPixel(x, y);
            return [p.r / 255.0, p.g / 255.0, p.b / 255.0];
          },
        ),
      ),
    );

    final outW = w * scale;
    final outH = h * scale;
    final output = List.generate(
      1,
      (_) => List.generate(
        outH,
        (_) => List.generate(outW, (_) => [0.0, 0.0, 0.0]),
      ),
    );

    interpreter.run(input, output);

    final result = img.Image(width: outW, height: outH);
    for (int y = 0; y < outH; y++) {
      for (int x = 0; x < outW; x++) {
        final px = output[0][y][x];
        result.setPixelRgba(
          x,
          y,
          (px[0] * 255.0).clamp(0, 255),
          (px[1] * 255.0).clamp(0, 255),
          (px[2] * 255.0).clamp(0, 255),
          255,
        );
      }
    }
    return result;
  }

  void _blendTileInto(
    img.Image output,
    Float32List weight,
    img.Image tile, {
    required int offsetX,
    required int offsetY,
    required int overlapPx,
  }) {
    for (int y = 0; y < tile.height; y++) {
      final oy = offsetY + y;
      if (oy < 0 || oy >= output.height) continue;
      for (int x = 0; x < tile.width; x++) {
        final ox = offsetX + x;
        if (ox < 0 || ox >= output.width) continue;

        // وزن أقل عند حواف التايل (feathering) عشان الدمج يبقى ناعم
        final wEdge = _featherWeight(x, y, tile.width, tile.height, overlapPx);

        final idx = oy * output.width + ox;
        final existing = output.getPixel(ox, oy);
        final prevW = weight[idx];
        final newW = prevW + wEdge;
        if (newW <= 0) continue;

        final src = tile.getPixel(x, y);
        final r = (existing.r * prevW + src.r * wEdge) / newW;
        final g = (existing.g * prevW + src.g * wEdge) / newW;
        final b = (existing.b * prevW + src.b * wEdge) / newW;

        output.setPixelRgba(ox, oy, r, g, b, 255);
        weight[idx] = newW;
      }
    }
  }

  double _featherWeight(int x, int y, int w, int h, int overlapPx) {
    if (overlapPx <= 0) return 1.0;
    double fx = 1.0, fy = 1.0;
    if (x < overlapPx) fx = (x + 1) / overlapPx;
    if (x >= w - overlapPx) fx = min(fx, (w - x) / overlapPx);
    if (y < overlapPx) fy = (y + 1) / overlapPx;
    if (y >= h - overlapPx) fy = min(fy, (h - y) / overlapPx);
    return (fx * fy).clamp(0.05, 1.0); // منخليهاش صفر تمامًا (تفادي قسمة صفرية)
  }

  void _normalizeByWeight(img.Image output, Float32List weight) {
    // الدمج بيتم أول بأول في _blendTileInto (weighted average)، فالخطوة دي
    // مجرد تأكيد إن مفيش بكسلات باقية بوزن صفر (حواف الصورة النهائية).
    for (int y = 0; y < output.height; y++) {
      for (int x = 0; x < output.width; x++) {
        final idx = y * output.width + x;
        if (weight[idx] <= 0) {
          // بكسل متغطاش بأي تايل (نادر جدًا، بيحصل بس في أخر صف/عمود لو
          // القسمة مش مظبوطة) — بناخد أقرب بكسل بدل ما يفضل أسود.
          final nx = x.clamp(0, output.width - 1);
          final ny = (y > 0 ? y - 1 : y).clamp(0, output.height - 1);
          output.setPixel(x, y, output.getPixel(nx, ny));
        }
      }
    }
  }

  /// يحسب factor التكبير المطلوب فعليًا للوصول لهدف 4K من غير ما نكبّر
  /// أكتر من اللازم (مطابقة لقاعدة "Do not create fake oversized resolution").
  int computeScaleFactor(ImageAnalysisResult analysis, {int modelNativeScale = 4}) {
    final longSide = max(analysis.width, analysis.height);
    if (longSide <= 0) return 1;
    final neededScale = AppConstants.max4kLongSide / longSide;
    if (neededScale <= 1.0) return 1; // الصورة أصلاً أكبر من 4K
    // منستخدمش factor أكبر من قدرة الموديل الطبيعية (x4 مثلاً) في مرة واحدة
    return min(modelNativeScale, max(1, neededScale.ceil()));
  }
}
