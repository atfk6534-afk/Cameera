import 'dart:math';
import 'package:image/image.dart' as img;

import '../core/constants.dart';
import '../models/image_analysis_result.dart';

/// خطوات "Main Restoration" (denoise/sharpen) و"Fallback Upscaling" المحلية.
/// كل الدوال هنا Dart خالص (من غير أي موديل AI محلي) — آمنة تمامًا تتنفّذ
/// جوه Isolate منفصل عشان متأثرش على سلاسة واجهة المستخدم.
/// الـ AI الحقيقي (Super-Resolution) بقى بيتم أونلاين عن طريق
/// RemoteEnhancementService؛ الدوال هنا هي خط الدفاع التاني (fallback)
/// لو مفيش إنترنت أو مفتاح API.
class EnhancementService {
  img.Image denoise(img.Image source, double strength) {
    if (strength <= 0.001) return source;
    final radius = (1 + strength * 2).round().clamp(1, 4);
    final blurred = img.gaussianBlur(source, radius: radius);
    return _linearBlend(source, blurred, strength.clamp(0.0, 0.6));
  }

  img.Image naturalSharpen(img.Image source, double amount) {
    if (amount <= 0.001) return source;
    final blurred = img.gaussianBlur(source, radius: 2);
    final result = img.Image.from(source);
    final a = amount.clamp(0.0, 0.5);

    for (int y = 0; y < source.height; y++) {
      for (int x = 0; x < source.width; x++) {
        final p = source.getPixel(x, y);
        final b = blurred.getPixel(x, y);

        final r = _sharpenChannel(p.r.toDouble(), b.r.toDouble(), a);
        final g = _sharpenChannel(p.g.toDouble(), b.g.toDouble(), a);
        final bChan = _sharpenChannel(p.b.toDouble(), b.b.toDouble(), a);

        result.setPixelRgba(x, y, r, g, bChan, p.a.toInt());
      }
    }
    return result;
  }

  double _sharpenChannel(double original, double blurred, double amount) {
    final v = original + amount * (original - blurred);
    return v.clamp(0, 255);
  }

  img.Image _linearBlend(img.Image a, img.Image b, double tOfB) {
    final result = img.Image.from(a);
    final t = tOfB.clamp(0.0, 1.0);
    for (int y = 0; y < a.height; y++) {
      for (int x = 0; x < a.width; x++) {
        final pa = a.getPixel(x, y);
        final pb = b.getPixel(x, y);
        result.setPixelRgba(
          x,
          y,
          pa.r * (1 - t) + pb.r * t,
          pa.g * (1 - t) + pb.g * t,
          pa.b * (1 - t) + pb.b * t,
          pa.a,
        );
      }
    }
    return result;
  }

  /// تكبير محلي عالي الجودة (Cubic) — بيستخدم لما الخدمة الأونلاين مش
  /// متاحة (مفيش نت / مفيش مفتاح API / فشل النداء).
  img.Image localUpscale(img.Image source, int factor) {
    if (factor <= 1) return source;
    return img.copyResize(
      source,
      width: source.width * factor,
      height: source.height * factor,
      interpolation: img.Interpolation.cubic,
    );
  }

  /// يحسب factor التكبير المطلوب فعليًا للوصول لهدف 4K من غير تكبير زيادة
  /// عن اللازم.
  int computeScaleFactor(ImageAnalysisResult analysis, {int maxScale = 4}) {
    final longSide = max(analysis.width, analysis.height);
    if (longSide <= 0) return 1;
    final neededScale = AppConstants.max4kLongSide / longSide;
    if (neededScale <= 1.0) return 1;
    return min(maxScale, max(1, neededScale.ceil()));
  }
}
