import 'dart:math';
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:onnxruntime_v2/onnxruntime_v2.dart';

import '../core/constants.dart';

/// Real-ESRGAN general x4v3, exported to ONNX.
/// The model accepts NCHW float32 RGB tensors in [0,1] and returns 4x output.
/// It is intentionally used in small overlapping tiles so mid-range phones do
/// not need to allocate a giant 4K tensor in one inference.
class EnhancementService {
  static bool _ortInitialized = false;
  OrtSession? _session;
  bool _modelReady = false;

  Future<bool> ensureModelLoaded() async {
    if (_modelReady && _session != null) return true;

    try {
      if (!_ortInitialized) {
        OrtEnv.instance.init();
        _ortInitialized = true;
      }

      final options = OrtSessionOptions();
      try {
        options.appendDefaultProviders();
      } catch (_) {
        // CPU fallback if hardware providers are not available.
      }

      final raw = await rootBundle.load(AppConstants.modelAssetPath);
      final bytes = raw.buffer.asUint8List();
      _session = OrtSession.fromBuffer(bytes, options);
      options.release();
      _modelReady = true;
      return true;
    } catch (_) {
      _session = null;
      _modelReady = false;
      return false;
    }
  }

  void dispose() {
    try {
      _session?.release();
    } catch (_) {}
    _session = null;
    _modelReady = false;
  }

  img.Image denoise(img.Image source, double strength) {
    if (strength <= 0.001) return source;
    final radius = (1 + strength * 2).round().clamp(1, 4);
    final blurred = img.gaussianBlur(source, radius: radius);
    return _linearBlend(source, blurred, strength.clamp(0.0, 0.45));
  }

  img.Image naturalSharpen(img.Image source, double amount) {
    if (amount <= 0.001) return source;
    final blurred = img.gaussianBlur(source, radius: 2);
    final result = img.Image.from(source);
    final a = amount.clamp(0.0, 0.35);

    for (int y = 0; y < source.height; y++) {
      for (int x = 0; x < source.width; x++) {
        final p = source.getPixel(x, y);
        final b = blurred.getPixel(x, y);
        result.setPixelRgba(
          x,
          y,
          _sharpen(p.r.toDouble(), b.r.toDouble(), a),
          _sharpen(p.g.toDouble(), b.g.toDouble(), a),
          _sharpen(p.b.toDouble(), b.b.toDouble(), a),
          p.a.toInt(),
        );
      }
    }
    return result;
  }

  double _sharpen(double original, double blurred, double amount) {
    return (original + (original - blurred) * amount).clamp(0.0, 255.0);
  }

  img.Image _linearBlend(img.Image a, img.Image b, double amount) {
    final out = img.Image.from(a);
    final t = amount.clamp(0.0, 1.0);
    for (int y = 0; y < a.height; y++) {
      for (int x = 0; x < a.width; x++) {
        final p = a.getPixel(x, y);
        final q = b.getPixel(x, y);
        out.setPixelRgba(
          x,
          y,
          p.r * (1 - t) + q.r * t,
          p.g * (1 - t) + q.g * t,
          p.b * (1 - t) + q.b * t,
          p.a.toInt(),
        );
      }
    }
    return out;
  }

  Future<img.Image> superResolve(
    img.Image source, {
    int modelScaleFactor = 4,
    void Function(double progress, String message)? onProgress,
  }) async {
    if (!_modelReady || _session == null) {
      throw StateError('Offline AI model is not loaded.');
    }

    if (source.width < 2 || source.height < 2) return source;

    final tile = _chooseTileSize(source.width, source.height);
    final overlap = min(AppConstants.tileOverlap, tile ~/ 8);
    final outWidth = source.width * modelScaleFactor;
    final outHeight = source.height * modelScaleFactor;

    final output = img.Image(width: outWidth, height: outHeight);
    final weights = Float32List(outWidth * outHeight);

    final xStarts = _starts(source.width, tile, overlap);
    final yStarts = _starts(source.height, tile, overlap);
    final total = xStarts.length * yStarts.length;
    int done = 0;

    for (final y0 in yStarts) {
      for (final x0 in xStarts) {
        final w = min(tile, source.width - x0);
        final h = min(tile, source.height - y0);
        final crop = img.copyCrop(source, x: x0, y: y0, width: w, height: h);

        final sr = await _runModelOnTile(crop, modelScaleFactor);
        _blendTileInto(
          output,
          weights,
          sr,
          offsetX: x0 * modelScaleFactor,
          offsetY: y0 * modelScaleFactor,
          overlapPx: overlap * modelScaleFactor,
        );

        done++;
        onProgress?.call(
          done / total,
          'AI Super Resolution  •  $done/$total',
        );
      }
    }

    return output;
  }

  int _chooseTileSize(int width, int height) {
    final pixels = width * height;
    if (pixels >= 6000000) return 64;
    if (pixels >= 2500000) return 96;
    return AppConstants.tileSize;
  }

  List<int> _starts(int length, int tile, int overlap) {
    if (length <= tile) return const [0];
    final step = max(1, tile - overlap * 2);
    final values = <int>[];
    for (int v = 0; v < length; v += step) {
      final start = min(v, length - tile);
      if (values.isEmpty || values.last != start) values.add(start);
      if (start == length - tile) break;
    }
    return values;
  }

  Future<img.Image> _runModelOnTile(img.Image tile, int scale) async {
    final session = _session!;
    final w = tile.width;
    final h = tile.height;

    // NCHW: [1,3,H,W]
    final data = Float32List(3 * w * h);
    int rBase = 0;
    int gBase = w * h;
    int bBase = 2 * w * h;

    for (int y = 0; y < h; y++) {
      for (int x = 0; x < w; x++) {
        final p = tile.getPixel(x, y);
        final i = y * w + x;
        data[rBase + i] = p.r / 255.0;
        data[gBase + i] = p.g / 255.0;
        data[bBase + i] = p.b / 255.0;
      }
    }

    final input = OrtValueTensor.createTensorWithDataList(
      data,
      [1, 3, h, w],
    );
    final runOptions = OrtRunOptions();

    try {
      final outputs = await session.runAsync(
        runOptions,
        {'input': input},
      );
      final first = outputs.firstWhere((v) => v != null)!;
      final value = first.value;
      final flat = _flattenNumbers(value);

      final outW = w * scale;
      final outH = h * scale;
      final expected = 3 * outW * outH;
      if (flat.length < expected) {
        throw StateError(
          'Unexpected AI output size: ${flat.length}, expected >= $expected',
        );
      }

      final out = img.Image(width: outW, height: outH);
      final plane = outW * outH;
      for (int y = 0; y < outH; y++) {
        for (int x = 0; x < outW; x++) {
          final i = y * outW + x;
          out.setPixelRgba(
            x,
            y,
            (flat[i] * 255.0).clamp(0.0, 255.0),
            (flat[plane + i] * 255.0).clamp(0.0, 255.0),
            (flat[plane * 2 + i] * 255.0).clamp(0.0, 255.0),
            255,
          );
        }
      }
      return out;
    } finally {
      input.release();
      runOptions.release();
      // Release output OrtValues when supported by the plugin.
      // Their native wrapper is ref-counted and the next inference is safe.
    }
  }

  List<double> _flattenNumbers(dynamic value) {
    final out = <double>[];
    void visit(dynamic v) {
      if (v is num) {
        out.add(v.toDouble());
      } else if (v is Iterable) {
        for (final item in v) visit(item);
      } else if (v is Float32List) {
        for (final item in v) out.add(item.toDouble());
      } else {
        throw StateError('Unsupported ONNX output type: ${v.runtimeType}');
      }
    }
    visit(value);
    return out;
  }

  void _blendTileInto(
    img.Image output,
    Float32List weight,
    img.Image tile, {
    required int offsetX,
    required int offsetY,
    required int overlapPx,
  }) {
    for (int y = 0; y < tile.height; y++) {
      final oy = offsetY + y;
      if (oy < 0 || oy >= output.height) continue;
      for (int x = 0; x < tile.width; x++) {
        final ox = offsetX + x;
        if (ox < 0 || ox >= output.width) continue;

        final edge = _featherWeight(x, y, tile.width, tile.height, overlapPx);
        final idx = oy * output.width + ox;
        final oldWeight = weight[idx];
        final newWeight = oldWeight + edge;
        final src = tile.getPixel(x, y);
        final old = output.getPixel(ox, oy);

        output.setPixelRgba(
          ox,
          oy,
          (old.r * oldWeight + src.r * edge) / newWeight,
          (old.g * oldWeight + src.g * edge) / newWeight,
          (old.b * oldWeight + src.b * edge) / newWeight,
          255,
        );
        weight[idx] = newWeight;
      }
    }
  }

  double _featherWeight(int x, int y, int w, int h, int overlap) {
    if (overlap <= 0) return 1.0;
    double fx = 1.0;
    double fy = 1.0;
    if (x < overlap) fx = (x + 1) / overlap;
    if (x >= w - overlap) fx = min(fx, (w - x) / overlap);
    if (y < overlap) fy = (y + 1) / overlap;
    if (y >= h - overlap) fy = min(fy, (h - y) / overlap);
    return (fx * fy).clamp(0.05, 1.0);
  }

  int computeScaleFactor(int width, int height, {int modelNativeScale = 4}) {
    final longSide = max(width, height);
    if (longSide <= 0) return 1;
    final targetScale = AppConstants.max4kLongSide / longSide;
    if (targetScale <= 1.0) return 1;
    return min(modelNativeScale, max(1, targetScale.ceil()));
  }
}
