import 'package:image/image.dart' as img;

import '../core/constants.dart';
import 'face_protection_service.dart';

/// خطوة "Original-Preservation Blend" من البرومبت:
/// Final = Enhanced × EnhancementConfidence + Original × PreservationConfidence
/// مع خفض إضافي جوه مناطق الوجوه حسب مستوى Face Protection المختار.
class BlendService {
  /// [original] و [enhanced] لازم يكونوا بنفس المقاس بالظبط قبل النداء —
  /// استخدم copyResize على original لو الأبعاد مختلفة بسبب الـ upscale.
  img.Image blend({
    required img.Image original,
    required img.Image enhanced,
    required EnhancementSettings settings,
    required List<ProtectedFaceRegion> faceRegions,
  }) {
    assert(original.width == enhanced.width && original.height == enhanced.height,
        'original و enhanced لازم يكونوا بنفس المقاس قبل الدمج');

    final result = img.Image(width: enhanced.width, height: enhanced.height);
    final globalConfidence = settings.globalEnhancementConfidence;
    final faceCap = settings.faceEnhancementConfidenceCap;

    for (int y = 0; y < enhanced.height; y++) {
      for (int x = 0; x < enhanced.width; x++) {
        double confidence = globalConfidence;

        // لو البكسل جوه منطقة وجه، نطبّق حد أقصى أشد (feathered عند الحواف)
        final region = _findRegion(faceRegions, x, y);
        if (region != null) {
          final dist = region.normalizedDistanceFromCenter(x, y); // 0..~2
          final feather = (dist).clamp(0.0, 1.0); // 0 بالمركز -> 1 عند الحافة
          // بالمركز بنستخدم الـ cap بالكامل، وكل ما اتبعدنا بنسمح بشوية
          // زيادة تدريجية لحد الـ globalConfidence عشان مفيش قطع مفاجئ.
          final localCap = faceCap + (globalConfidence - faceCap) * feather;
          confidence = confidence < localCap ? confidence : localCap;
        }

        final o = original.getPixel(x, y);
        final e = enhanced.getPixel(x, y);
        final preservation = 1.0 - confidence;

        result.setPixelRgba(
          x,
          y,
          e.r * confidence + o.r * preservation,
          e.g * confidence + o.g * preservation,
          e.b * confidence + o.b * preservation,
          255,
        );
      }
    }
    return result;
  }

  ProtectedFaceRegion? _findRegion(List<ProtectedFaceRegion> regions, int x, int y) {
    for (final r in regions) {
      if (r.contains(x, y)) return r;
    }
    return null;
  }

  /// خطوة "Quality Validation -> Detect suspicious alteration -> Blend with
  /// original -> Re-check". بنعمل *مرة واحدة إضافية* بس (مش loop لانهائي)
  /// لو التشابه في منطقة وجه معينة واطي جدًا، عشان نضمن استقرار وسرعة متوقعة.
  img.Image reinforceIfSuspicious({
    required img.Image original,
    required img.Image blended,
    required List<ProtectedFaceRegion> faceRegions,
    required double Function(ProtectedFaceRegion) similarityOf,
    double similarityThreshold = 0.75,
  }) {
    var current = blended;
    for (final region in faceRegions) {
      final similarity = similarityOf(region);
      if (similarity >= similarityThreshold) continue;

      // كل ما التشابه قل عن الحد، بنزود نسبة الأصلي جوه المنطقة دي تحديدًا
      final extraPreservation = (similarityThreshold - similarity).clamp(0.0, 0.6);
      current = _blendRegionTowardOriginal(current, original, region, extraPreservation);
    }
    return current;
  }

  img.Image _blendRegionTowardOriginal(
    img.Image current,
    img.Image original,
    ProtectedFaceRegion region,
    double extraOriginalWeight,
  ) {
    final result = img.Image.from(current);
    for (int y = region.top; y < region.bottom; y++) {
      if (y < 0 || y >= result.height) continue;
      for (int x = region.left; x < region.right; x++) {
        if (x < 0 || x >= result.width) continue;
        final c = current.getPixel(x, y);
        final o = original.getPixel(x, y);
        final w = extraOriginalWeight;
        result.setPixelRgba(
          x,
          y,
          c.r * (1 - w) + o.r * w,
          c.g * (1 - w) + o.g * w,
          c.b * (1 - w) + o.b * w,
          255,
        );
      }
    }
    return result;
  }
}
