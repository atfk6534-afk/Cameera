import 'dart:math';
import 'package:image/image.dart' as img;

import '../core/constants.dart';
import '../models/image_analysis_result.dart';

/// خطوة "Automatic Image Analysis" + "Quality Classification" من البرومبت.
/// كل الحسابات هنا local بالكامل (بدون إنترنت) وبتشتغل على grayscale نسخة
/// خفيفة من الصورة عشان الأداء يبقى كويس على الموبايل.
class ImageAnalysisService {
  /// أقصى ضلع للنسخة المصغّرة المستخدمة في التحليل فقط (مش في المخرج النهائي)
  static const int _analysisMaxSide = 512;

  ImageAnalysisResult analyze(img.Image original) {
    if (original.width < AppConstants.minSafeDimension ||
        original.height < AppConstants.minSafeDimension) {
      // صورة صغيرة جدًا أو تالفة — بنرجع تصنيف آمن بدل ما نكسر الحسابات
      return ImageAnalysisResult(
        width: original.width,
        height: original.height,
        blurScore: 0,
        noiseScore: 0,
        averageBrightness: 128,
        dynamicRange: 0,
        qualityClass: ImageQualityClass.extremelyLow,
      );
    }

    final sample = _downscaleForAnalysis(original);
    final gray = img.grayscale(sample);

    final blur = _laplacianVariance(gray);
    final noise = _highFrequencyNoiseEstimate(gray);
    final brightness = _averageBrightness(gray);
    final range = _dynamicRange(gray);

    final qualityClass = _classify(
      blur: blur,
      noise: noise,
      width: original.width,
      height: original.height,
    );

    return ImageAnalysisResult(
      width: original.width,
      height: original.height,
      blurScore: blur,
      noiseScore: noise,
      averageBrightness: brightness,
      dynamicRange: range,
      qualityClass: qualityClass,
    );
  }

  img.Image _downscaleForAnalysis(img.Image src) {
    final longSide = max(src.width, src.height);
    if (longSide <= _analysisMaxSide) return src;
    final scale = _analysisMaxSide / longSide;
    return img.copyResize(
      src,
      width: (src.width * scale).round(),
      height: (src.height * scale).round(),
      interpolation: img.Interpolation.average,
    );
  }

  /// تقدير الوضوح بطريقة تشبه Laplacian variance:
  /// كل ما كان تباين الحواف عالي = الصورة أوضح (مش مموّهة/مش blur).
  double _laplacianVariance(img.Image gray) {
    final edges = img.sobel(gray); // يبرز الحواف
    final values = <double>[];
    for (final p in edges) {
      values.add(p.luminance.toDouble());
    }
    if (values.isEmpty) return 0;
    final mean = values.reduce((a, b) => a + b) / values.length;
    final variance =
        values.map((v) => (v - mean) * (v - mean)).reduce((a, b) => a + b) /
            values.length;
    return variance;
  }

  /// تقدير مبسّط للتشويش: فرق الصورة عن نسخة منعّمة منها في المناطق المسطحة
  /// (مناطق منخفضة التدرّج) — لتفادي الخلط بين "تفاصيل حقيقية" و"تشويش".
  double _highFrequencyNoiseEstimate(img.Image gray) {
    final blurred = img.gaussianBlur(gray, radius: 2);
    final edges = img.sobel(gray);

    double sum = 0;
    int count = 0;
    for (int y = 0; y < gray.height; y++) {
      for (int x = 0; x < gray.width; x++) {
        final edgeStrength = edges.getPixel(x, y).luminance.toDouble();
        // نعتبر المنطقة "مسطحة" (مفيهاش تفاصيل حقيقية) لو الحافة ضعيفة
        if (edgeStrength < 10) {
          final a = gray.getPixel(x, y).luminance.toDouble();
          final b = blurred.getPixel(x, y).luminance.toDouble();
          sum += (a - b).abs();
          count++;
        }
      }
    }
    if (count == 0) return 0;
    return sum / count;
  }

  double _averageBrightness(img.Image gray) {
    double sum = 0;
    int count = 0;
    for (final p in gray) {
      sum += p.luminance.toDouble();
      count++;
    }
    return count == 0 ? 128 : sum / count;
  }

  double _dynamicRange(img.Image gray) {
    double minV = 255, maxV = 0;
    for (final p in gray) {
      final l = p.luminance.toDouble();
      if (l < minV) minV = l;
      if (l > maxV) maxV = l;
    }
    return maxV - minV;
  }

  ImageQualityClass _classify({
    required double blur,
    required double noise,
    required int width,
    required int height,
  }) {
    final megapixels = (width * height) / 1000000;

    // عتبات مبنية على تجارب عملية على صور موبايل عادية — قابلة للتعديل.
    final isSharp = blur > 350;
    final isModeratelySharp = blur > 120;
    final isNoisy = noise > 9;
    final isVeryNoisy = noise > 18;
    final isLowRes = megapixels < 0.5; // أقل من نص ميجابكسل

    if (isLowRes && (isVeryNoisy || blur < 40)) {
      return ImageQualityClass.extremelyLow;
    }
    if (isSharp && !isNoisy && megapixels >= 2) {
      return ImageQualityClass.high;
    }
    if (isModeratelySharp && !isVeryNoisy) {
      return ImageQualityClass.medium;
    }
    return ImageQualityClass.low;
  }
}
