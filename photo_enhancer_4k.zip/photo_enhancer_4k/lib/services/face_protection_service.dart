import 'dart:io';
import 'dart:typed_data';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:image/image.dart' as img;

/// مستطيل وجه بمقاسات صورة الـ pixel buffer (مش صورة الجهاز الأصلية)
class ProtectedFaceRegion {
  final int left, top, right, bottom;
  const ProtectedFaceRegion(this.left, this.top, this.right, this.bottom);

  bool contains(int x, int y) => x >= left && x < right && y >= top && y < bottom;

  /// مسافة نسبية من مركز الوجه (0 = المركز بالظبط) — تستخدم في feather blending
  double normalizedDistanceFromCenter(int x, int y) {
    final cx = (left + right) / 2;
    final cy = (top + bottom) / 2;
    final halfW = (right - left) / 2;
    final halfH = (bottom - top) / 2;
    if (halfW <= 0 || halfH <= 0) return 1.0;
    final dx = (x - cx) / halfW;
    final dy = (y - cy) / halfH;
    return (dx * dx + dy * dy).clamp(0.0, 4.0);
  }
}

/// خطوة "Face Detection -> Identity Protection" من البرومبت.
/// الكشف بيتم بالكامل على الجهاز (ML Kit on-device model) — من غير إنترنت.
class FaceProtectionService {
  final FaceDetector _detector = FaceDetector(
    options: FaceDetectorOptions(
      performanceMode: FaceDetectorMode.accurate,
      enableLandmarks: false,
      enableContours: false,
      enableClassification: false,
      minFaceSize: 0.05,
    ),
  );

  /// بياخد مسار ملف الصورة الأصلي (مطلوب من ML Kit) ويرجّع مستطيلات الوجوه
  /// مُسقَطة (scaled) على مقاسات [pixelWidth]x[pixelHeight] اللي المعالجة شغالة عليها.
  Future<List<ProtectedFaceRegion>> detectFaces({
    required File imageFile,
    required int sourceWidth,
    required int sourceHeight,
    required int pixelWidth,
    required int pixelHeight,
  }) async {
    try {
      final input = InputImage.fromFile(imageFile);
      final faces = await _detector.processImage(input);
      if (faces.isEmpty) return const [];

      final scaleX = pixelWidth / sourceWidth;
      final scaleY = pixelHeight / sourceHeight;

      // هامش أمان حوالي 15% حوالين الوجه عشان يغطي الشعر/الأذنين كمان
      const marginRatio = 0.15;

      return faces.map((f) {
        final rect = f.boundingBox;
        final marginX = rect.width * marginRatio;
        final marginY = rect.height * marginRatio;

        final left = ((rect.left - marginX) * scaleX)
            .round()
            .clamp(0, pixelWidth - 1);
        final top = ((rect.top - marginY) * scaleY)
            .round()
            .clamp(0, pixelHeight - 1);
        final right = ((rect.right + marginX) * scaleX)
            .round()
            .clamp(1, pixelWidth);
        final bottom = ((rect.bottom + marginY) * scaleY)
            .round()
            .clamp(1, pixelHeight);

        return ProtectedFaceRegion(left, top, right, bottom);
      }).toList();
    } catch (_) {
      // لو الكشف فشل لأي سبب، الأفضل نكمّل من غير حماية وجوه إضافية
      // بدل ما نوقف كل عملية التحسين (fail-safe, مش fail-stop).
      return const [];
    }
  }

  /// فحص تشابه مبسّط بين الصورة الأصلية والمُحسَّنة داخل منطقة الوجه
  /// (خطوة "Quality Validation" -> Identity similarity check).
  /// بيرجع قيمة 0..1: 1 = تطابق شبه كامل، القيم الواطية تعني تغيّر كبير
  /// في البنية يستوجب زيادة نسبة الحفاظ على الأصل (blend أكتر من original).
  double structuralSimilarity(
    img.Image original,
    img.Image enhanced,
    ProtectedFaceRegion region,
  ) {
    double diffSum = 0;
    int count = 0;
    for (int y = region.top; y < region.bottom; y += 2) {
      for (int x = region.left; x < region.right; x += 2) {
        if (x >= original.width ||
            y >= original.height ||
            x >= enhanced.width ||
            y >= enhanced.height) {
          continue;
        }
        final a = original.getPixel(x, y).luminance.toDouble();
        final b = enhanced.getPixel(x, y).luminance.toDouble();
        diffSum += (a - b).abs();
        count++;
      }
    }
    if (count == 0) return 1.0;
    final avgDiff = diffSum / count; // 0..255
    return (1.0 - (avgDiff / 255.0)).clamp(0.0, 1.0);
  }

  void dispose() {
    _detector.close();
  }
}

/// Helper بسيط لتحويل bytes لصورة File مؤقتة عند الحاجة (ML Kit يفضّل File/path)
class TempFileHelper {
  static Future<File> writeTemp(Uint8List bytes, String path) async {
    final file = File(path);
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }
}
