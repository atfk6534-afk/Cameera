import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/foundation.dart' show compute;
import 'package:image/image.dart' as img;

import '../core/constants.dart';
import '../core/ai_provider.dart';
import '../models/image_analysis_result.dart';
import 'api_key_store.dart';
import 'image_analysis_service.dart';
import 'face_protection_service.dart';
import 'enhancement_service.dart';
import 'blend_service.dart';
import 'remote_enhancement_service.dart';

enum PipelineStep {
  analyzing,
  restoringDetails,
  protectingIdentity,
  enhancingTextures,
  upscaling,
  finalizing,
  done,
}

class PipelineResult {
  final Uint8List originalPngBytes;
  final Uint8List enhancedPngBytes;
  final ImageAnalysisResult analysis;
  final bool aiAttempted; // true لو المستخدم مختار مزوّد AI (مش "بدون AI")
  final bool usedRealModel; // true = التحسين الأونلاين فعلاً نجح ورجّع نتيجة

  const PipelineResult({
    required this.originalPngBytes,
    required this.enhancedPngBytes,
    required this.analysis,
    required this.aiAttempted,
    required this.usedRealModel,
  });
}

/// الأوركستريتور الكامل. المسار الافتراضي (بدون AI): فلاتر تلقائية
/// محلية بس (Auto Levels/White Balance/Vibrance/Sharpen) — سريعة
/// وموثوقة 100%، النتيجة بتظهر خلال ثواني. لو المستخدم اختار مزوّد AI
/// من الإعدادات، بيتضاف فوق الفلاتر دي محاولة Super-Resolution أونلاين
/// مع حماية كاملة ضد التوهّم (hallucination) عن طريق دمج بالثقة مع
/// الأصل. الجزء التقيل كله شغال جوه Isolate منفصل عن طريق compute()،
/// فواجهة المستخدم مبتعلقش خالص.
class EnhancementPipeline {
  final FaceProtectionService _faceService = FaceProtectionService();
  final ApiKeyStore _apiKeyStore = ApiKeyStore();

  Future<PipelineResult> run({
    required File imageFile,
    required EnhancementSettings settings,
    void Function(PipelineStep step)? onStep,
  }) async {
    onStep?.call(PipelineStep.analyzing);
    final originalBytes = await imageFile.readAsBytes();

    final decodedForFaces = img.decodeImage(originalBytes);
    if (decodedForFaces == null) {
      throw const FormatException(
          'تعذّر قراءة الصورة — تأكد إن الصيغة JPG/PNG/WEBP');
    }

    final selectedProvider = await _apiKeyStore.readSelectedProvider();
    final aiAttempted = selectedProvider.requiresNetwork;

    // كشف الوجوه مطلوب بس لو فيه AI هيتم استخدامه (للحماية من التوهّم).
    // المسار المحلي البحت (الافتراضي) مش محتاجه خالص فبنوفّر الوقت.
    List<Map<String, int>> faceRegionsData = const [];
    if (aiAttempted) {
      onStep?.call(PipelineStep.protectingIdentity);
      final faceRegions = await _faceService
          .detectFaces(
            imageFile: imageFile,
            sourceWidth: decodedForFaces.width,
            sourceHeight: decodedForFaces.height,
            pixelWidth: decodedForFaces.width,
            pixelHeight: decodedForFaces.height,
          )
          .timeout(const Duration(seconds: 15), onTimeout: () => const []);
      faceRegionsData = faceRegions
          .map((r) => {
                'left': r.left,
                'top': r.top,
                'right': r.right,
                'bottom': r.bottom,
              })
          .toList();
    }

    final apiKey = await _apiKeyStore.readKey(selectedProvider);
    final hfSpaceId = await _apiKeyStore.readHfSpace();

    onStep?.call(PipelineStep.restoringDetails);
    onStep?.call(PipelineStep.upscaling);

    // كل المعالجة التقيلة بتتنفّذ هنا جوه isolate منفصل بالكامل.
    // ★ خط دفاع أخير: مهلة زمنية شاملة — المسار المحلي البحت سريع جدًا
    // فمهلته قصيرة، ومسار الـ AI محتاج وقت أطول لنداءات الشبكة.
    final overallTimeout =
        aiAttempted ? const Duration(minutes: 2) : const Duration(seconds: 30);

    final resultMap = await compute(_runHeavyEnhancement, {
      'originalBytes': originalBytes,
      'enhancement': settings.enhancement.index,
      'faceProtection': settings.faceProtection.index,
      'noiseReduction': settings.noiseReduction.index,
      'output': settings.output.index,
      'provider': selectedProvider.index,
      'apiKey': apiKey,
      'hfSpaceId': hfSpaceId,
      'faceRegions': faceRegionsData,
    }).timeout(
      overallTimeout,
      onTimeout: () => throw TimeoutException(
        'المعالجة أخدت وقت أطول من المتوقع. جرّب تاني، أو اختار '
        '"فلاتر محلية فقط" من الإعدادات عشان نتيجة فورية دايمًا.',
      ),
    );

    onStep?.call(PipelineStep.enhancingTextures);
    onStep?.call(PipelineStep.finalizing);

    final analysis = ImageAnalysisResult(
      width: resultMap['width'] as int,
      height: resultMap['height'] as int,
      blurScore: 0,
      noiseScore: 0,
      averageBrightness: 128,
      dynamicRange: 0,
      qualityClass: ImageQualityClass.values[resultMap['qualityClass'] as int],
    );

    onStep?.call(PipelineStep.done);

    return PipelineResult(
      originalPngBytes: resultMap['originalBytes'] as Uint8List,
      enhancedPngBytes: resultMap['enhancedBytes'] as Uint8List,
      analysis: analysis,
      aiAttempted: aiAttempted,
      usedRealModel: resultMap['usedRemote'] as bool,
    );
  }

  void dispose() {
    _faceService.dispose();
  }
}

// ---------------------------------------------------------------------
// الدالة دي لازم تفضل top-level (مش method جوه كلاس) عشان compute()
// يقدر يبعتها لـ isolate منفصل. كل حاجة بتستخدمها هنا Dart خالص أو
// نداءات شبكة (http) — مفيش أي platform channel، فآمنة 100% جوه isolate.
// ---------------------------------------------------------------------
Future<Map<String, dynamic>> _runHeavyEnhancement(
  Map<String, dynamic> args,
) async {
  final originalBytes = args['originalBytes'] as Uint8List;
  final provider = AiProvider.values[args['provider'] as int];
  final apiKey = args['apiKey'] as String;
  final hfSpaceId = args['hfSpaceId'] as String;
  final faceRegionsRaw = args['faceRegions'] as List;
  final useAi = provider.requiresNetwork;

  final settings = EnhancementSettings(
    enhancement: EnhancementLevel.values[args['enhancement'] as int],
    faceProtection: FaceProtectionLevel.values[args['faceProtection'] as int],
    noiseReduction: NoiseReductionLevel.values[args['noiseReduction'] as int],
    output: OutputMode.values[args['output'] as int],
  );

  final analysisService = ImageAnalysisService();
  final enhancementService = EnhancementService();
  final blendService = BlendService();
  final remoteService = RemoteEnhancementService();

  final decoded = img.decodeImage(originalBytes);
  if (decoded == null) {
    throw const FormatException('تعذّر قراءة الصورة داخل المعالجة');
  }
  final immutableOriginal = img.Image.from(decoded);
  final analysis = analysisService.analyze(immutableOriginal);
  final profile = analysis.profile;

  // --- تحديد حجم شغل آمن للمعالجة اليدوية (denoise/color/sharpen) ---
  // ده أهم خطوة لتفادي التعليق: صور الكاميرا الحديثة (12-48 ميجابكسل)
  // لو اتعالجت بيكسل-بيكسل على حجمها الكامل بتاخد دقايق. فبنصغّرها
  // لحجم معقول الأول، ونعالج على الحجم ده بس، وبعدين نكبّر في الآخر.
  final processingBase = enhancementService.capForProcessing(immutableOriginal);

  // --- Denoise ---
  final denoiseAmount =
      (profile.denoiseStrength * settings.denoiseMultiplier).clamp(0.0, 1.0);
  var working = enhancementService.denoise(processingBase, denoiseAmount);

  // --- Auto-Enhance الألوان (White Balance + Levels + Vibrance) ---
  // ده اللي بيدّي "الشكل الحلو الواضح" اللي المستخدم عايزه فورًا، من
  // غير أي AI أو نداء شبكة — بيشتغل دايمًا بغض النظر عن المزوّد المختار.
  final vibrance = switch (settings.enhancement) {
    EnhancementLevel.natural => 0.10,
    EnhancementLevel.balanced => 0.18,
    EnhancementLevel.strong => 0.28,
  };
  working = enhancementService.autoEnhanceColor(working, vibranceAmount: vibrance);

  // --- تكبير للحجم المستهدف: محلي دايمًا للمسار الافتراضي، أو محاولة
  // أونلاين لو المستخدم اختار مزوّد AI (مع fallback محلي لو فشل) ---
  final scaleFactor = settings.output == OutputMode.fourK
      ? enhancementService.computeScaleFactorFor(working.width, working.height)
      : 1;

  img.Image upscaled;
  bool usedRemote = false;

  if (scaleFactor > 1) {
    Uint8List? remoteBytes;
    if (useAi && (provider.worksWithoutKey || apiKey.trim().isNotEmpty)) {
      final workingPng = Uint8List.fromList(img.encodePng(working));
      remoteBytes = await remoteService.upscale(
        imageBytes: workingPng,
        provider: provider,
        apiKey: apiKey,
        hfSpaceId: hfSpaceId,
        scale: scaleFactor,
      );
    }

    if (remoteBytes != null) {
      final remoteDecoded = img.decodeImage(remoteBytes);
      if (remoteDecoded != null) {
        upscaled = remoteDecoded;
        usedRemote = true;
      } else {
        upscaled = enhancementService.localUpscale(working, scaleFactor);
      }
    } else {
      upscaled = enhancementService.localUpscale(working, scaleFactor);
    }
  } else {
    upscaled = working;
  }

  // تأمين إضافي: أي مصدر تكبير ممكن يرجّع حجم أكبر من اللازم — بنضمن
  // إن الحجم النهائي مايتعديش سقف الـ 4K المستهدف قبل خطوات تقيلة تانية.
  final upscaledLongSide = max(upscaled.width, upscaled.height);
  if (upscaledLongSide > AppConstants.max4kLongSide) {
    final downScale = AppConstants.max4kLongSide / upscaledLongSide;
    upscaled = img.copyResize(
      upscaled,
      width: (upscaled.width * downScale).round(),
      height: (upscaled.height * downScale).round(),
      interpolation: img.Interpolation.average,
    );
  }

  // --- Natural Sharpening (Clarity) ---
  final sharpenAmount = 0.15 + profile.detailRecovery * 0.35;
  upscaled = enhancementService.naturalSharpen(upscaled, sharpenAmount);

  img.Image finalImage;

  if (!useAi) {
    // المسار المحلي البحت: مفيش أي احتمال "توهّم" أو اختراع تفاصيل —
    // كل العمليات دي حتمية (deterministic) وآمنة على الهوية، فمش محتاجين
    // ندمج مع الأصل تاني (ده كان بس لحماية نتيجة الـ AI الأونلاين).
    finalImage = upscaled;
  } else {
    // --- Confidence Blending مع الأصل (حماية من توهّم الـ AI) ---
    final originalResized =
        (upscaled.width != immutableOriginal.width ||
                upscaled.height != immutableOriginal.height)
            ? img.copyResize(
                immutableOriginal,
                width: upscaled.width,
                height: upscaled.height,
                interpolation: img.Interpolation.cubic,
              )
            : immutableOriginal;

    final effectiveScaleX = immutableOriginal.width > 0
        ? upscaled.width / immutableOriginal.width
        : 1.0;
    final effectiveScaleY = immutableOriginal.height > 0
        ? upscaled.height / immutableOriginal.height
        : 1.0;

    final faceRegions = faceRegionsRaw.map((raw) {
      final m = raw as Map;
      return ProtectedFaceRegion(
        ((m['left'] as int) * effectiveScaleX).round(),
        ((m['top'] as int) * effectiveScaleY).round(),
        ((m['right'] as int) * effectiveScaleX).round(),
        ((m['bottom'] as int) * effectiveScaleY).round(),
      );
    }).toList();

    var blended = blendService.blend(
      original: originalResized,
      enhanced: upscaled,
      settings: settings,
      faceRegions: faceRegions,
    );

    if (faceRegions.isNotEmpty) {
      blended = blendService.reinforceIfSuspicious(
        original: originalResized,
        blended: blended,
        faceRegions: faceRegions,
        similarityOf: (region) =>
            _structuralSimilarity(originalResized, blended, region),
      );
    }

    finalImage = blended;
  }

  final enhancedPng = Uint8List.fromList(img.encodePng(finalImage));
  final originalPng = Uint8List.fromList(img.encodePng(immutableOriginal));

  return {
    'enhancedBytes': enhancedPng,
    'originalBytes': originalPng,
    'width': analysis.width,
    'height': analysis.height,
    'qualityClass': analysis.qualityClass.index,
    'usedRemote': usedRemote,
  };
}

/// نسخة Dart خالصة من فحص التشابه (بدون أي اعتماد على ML Kit) — آمنة
/// 100% جوه الـ isolate. نفس منطق FaceProtectionService.structuralSimilarity.
double _structuralSimilarity(
  img.Image original,
  img.Image enhanced,
  ProtectedFaceRegion region,
) {
  double diffSum = 0;
  int count = 0;
  for (int y = region.top; y < region.bottom; y += 2) {
    for (int x = region.left; x < region.right; x += 2) {
      if (x >= original.width ||
          y >= original.height ||
          x >= enhanced.width ||
          y >= enhanced.height) {
        continue;
      }
      final a = original.getPixel(x, y).luminance.toDouble();
      final b = enhanced.getPixel(x, y).luminance.toDouble();
      diffSum += (a - b).abs();
      count++;
    }
  }
  if (count == 0) return 1.0;
  final avgDiff = diffSum / count;
  return (1.0 - (avgDiff / 255.0)).clamp(0.0, 1.0);
}
