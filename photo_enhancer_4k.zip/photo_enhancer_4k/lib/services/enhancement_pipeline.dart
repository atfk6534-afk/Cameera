import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:image/image.dart' as img;

import '../core/constants.dart';
import '../models/image_analysis_result.dart';
import 'image_analysis_service.dart';
import 'face_protection_service.dart';
import 'enhancement_service.dart';
import 'blend_service.dart';

enum PipelineStep {
  analyzing,
  restoringDetails,
  protectingIdentity,
  enhancingTextures,
  upscaling,
  finalizing,
  done,
}

class PipelineResult {
  final Uint8List originalPngBytes;
  final Uint8List enhancedPngBytes;
  final ImageAnalysisResult analysis;
  final bool usedRealModel; // false يعني استخدمنا fallback تكبير تقليدي

  const PipelineResult({
    required this.originalPngBytes,
    required this.enhancedPngBytes,
    required this.analysis,
    required this.usedRealModel,
  });
}

/// خطوة "Final Pipeline" الكاملة من البرومبت — من الصورة الأصلية لحد
/// المخرج النهائي، بالكامل offline. كل خطوة بتنادي callback [onStep]
/// عشان شاشة الـ Processing تعرض الحالة الحالية للمستخدم.
class EnhancementPipeline {
  final ImageAnalysisService _analysisService = ImageAnalysisService();
  final FaceProtectionService _faceService = FaceProtectionService();
  final EnhancementService _enhancementService = EnhancementService();
  final BlendService _blendService = BlendService();

  Future<PipelineResult> run({
    required File imageFile,
    required EnhancementSettings settings,
    void Function(PipelineStep step)? onStep,
  }) async {
    // --- Step 1: Input + إنشاء نسخة أصلية غير قابلة للتعديل ---
    final originalBytes = await imageFile.readAsBytes();
    final decoded = img.decodeImage(originalBytes);
    if (decoded == null) {
      throw const FormatException('تعذّر قراءة الصورة — تأكد إن الصيغة JPG/PNG/WEBP');
    }
    final immutableOriginal = img.Image.from(decoded); // نسخة احتياطية ثابتة

    // --- Step 2 & 3: Analysis + Quality Classification ---
    onStep?.call(PipelineStep.analyzing);
    final analysis = _analysisService.analyze(immutableOriginal);

    // --- Step 4: Face Detection (on-device) ---
    onStep?.call(PipelineStep.protectingIdentity);
    final faceRegions = await _faceService.detectFaces(
      imageFile: imageFile,
      sourceWidth: decoded.width,
      sourceHeight: decoded.height,
      pixelWidth: decoded.width,
      pixelHeight: decoded.height,
    );

    // --- Step 5: Main Restoration (denoise + إعداد للـ deblur) ---
    onStep?.call(PipelineStep.restoringDetails);
    final profile = analysis.profile;
    final denoiseAmount =
        (profile.denoiseStrength * settings.denoiseMultiplier).clamp(0.0, 1.0);
    var working = _enhancementService.denoise(immutableOriginal, denoiseAmount);

    // --- Step 6/8: Face-aware Super Resolution ---
    onStep?.call(PipelineStep.upscaling);
    final modelReady = await _enhancementService.ensureModelLoaded();

    img.Image upscaled = working;

    if (modelReady && settings.output == OutputMode.fourK) {
      final longSide = max(working.width, working.height);
      const targetLongSide = AppConstants.max4kLongSide;

      // Real-ESRGAN x4 is the neural step. For a 4K target, when the source
      // is smaller than 4K we can pre-size it near target/4, run x4 AI, then
      // make the exact final dimensions. This prevents unnecessarily huge
      // 4x tensors on phones while still feeding the model a useful number of
      // native pixels.
      final targetInputLongSide = (targetLongSide / 4).round();
      var modelInput = working;
      if (longSide > targetInputLongSide && targetInputLongSide >= AppConstants.minSafeDimension) {
        final factor = targetInputLongSide / longSide;
        final w = max(
          AppConstants.minSafeDimension,
          (working.width * factor).round(),
        );
        final h = max(
          AppConstants.minSafeDimension,
          (working.height * factor).round(),
        );
        modelInput = img.copyResize(
          working,
          width: w,
          height: h,
          interpolation: img.Interpolation.cubic,
        );
      }

      upscaled = await _enhancementService.superResolve(
        modelInput,
        modelScaleFactor: 4,
        onProgress: (p, message) => onStep?.call(PipelineStep.upscaling),
      );

      final finalSize = _targetSize(
        upscaled.width,
        upscaled.height,
        targetLongSide,
      );
      if (finalSize.$1 != upscaled.width || finalSize.$2 != upscaled.height) {
        upscaled = img.copyResize(
          upscaled,
          width: finalSize.$1,
          height: finalSize.$2,
          interpolation: img.Interpolation.cubic,
        );
      }
    } else if (modelReady && settings.output == OutputMode.originalAspect) {
      upscaled = await _enhancementService.superResolve(
        working,
        modelScaleFactor: 4,
        onProgress: (p, message) => onStep?.call(PipelineStep.upscaling),
      );
    } else {
      // Model failure is a hard error in this release: never pretend a normal
      // resize is AI enhancement. The user gets a clear error screen instead.
      throw StateError(
        'Offline AI model could not be loaded. Please reinstall the APK or rebuild it so the ONNX model is bundled.',
      );
    }

    // --- Step: Natural Sharpening (بعد التكبير عشان التفاصيل تبان صح)
    onStep?.call(PipelineStep.enhancingTextures);
    final sharpenAmount = profile.detailRecovery * 0.4; // سقف أمان
    upscaled = _enhancementService.naturalSharpen(upscaled, sharpenAmount);

    // --- Step 9/10: Validation + Confidence Blending مع الأصل ---
    onStep?.call(PipelineStep.finalizing);
    final originalResized = img.copyResize(
      immutableOriginal,
      width: upscaled.width,
      height: upscaled.height,
      interpolation: img.Interpolation.cubic,
    );

    final sx = upscaled.width / immutableOriginal.width;
    final sy = upscaled.height / immutableOriginal.height;
    final scaledFaceRegions = faceRegions
        .map((r) => ProtectedFaceRegion(
              (r.left * sx),
              (r.top * sy),
              (r.right * sx),
              (r.bottom * sy),
            ))
        .toList();

    var blended = _blendService.blend(
      original: originalResized,
      enhanced: upscaled,
      settings: settings,
      faceRegions: scaledFaceRegions,
    );

    // فحص تشابه إضافي مرة واحدة على الوجوه (مش loop) — لو في وجه اتغيّر
    // كتير، بنزوّد نسبة الحفاظ على الأصل جواه بس.
    if (scaledFaceRegions.isNotEmpty) {
      blended = _blendService.reinforceIfSuspicious(
        original: originalResized,
        blended: blended,
        faceRegions: scaledFaceRegions,
        similarityOf: (region) => _faceService.structuralSimilarity(
          originalResized,
          blended,
          region,
        ),
      );
    }

    // --- Step 11: Export ---
    final enhancedPng = Uint8List.fromList(img.encodePng(blended));
    final originalPng = Uint8List.fromList(img.encodePng(immutableOriginal));

    onStep?.call(PipelineStep.done);

    return PipelineResult(
      originalPngBytes: originalPng,
      enhancedPngBytes: enhancedPng,
      analysis: analysis,
      usedRealModel: modelReady,
    );
  }

  (int, int) _targetSize(int width, int height, int targetLongSide) {
    final longSide = max(width, height);
    if (longSide <= targetLongSide) return (width, height);
    final scale = targetLongSide / longSide;
    return (
      max(AppConstants.minSafeDimension, (width * scale).round()),
      max(AppConstants.minSafeDimension, (height * scale).round()),
    );
  }

  void dispose() {
    _faceService.dispose();
    _enhancementService.dispose();
  }
}
