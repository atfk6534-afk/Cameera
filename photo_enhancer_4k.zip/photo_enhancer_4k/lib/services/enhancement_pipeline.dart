import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;

import '../core/constants.dart';
import '../models/image_analysis_result.dart';
import 'image_analysis_service.dart';
import 'face_protection_service.dart';
import 'enhancement_service.dart';
import 'blend_service.dart';

enum PipelineStep {
  analyzing,
  restoringDetails,
  protectingIdentity,
  enhancingTextures,
  upscaling,
  finalizing,
  done,
}

class PipelineResult {
  final Uint8List originalPngBytes;
  final Uint8List enhancedPngBytes;
  final ImageAnalysisResult analysis;
  final bool usedRealModel; // false يعني استخدمنا fallback تكبير تقليدي

  const PipelineResult({
    required this.originalPngBytes,
    required this.enhancedPngBytes,
    required this.analysis,
    required this.usedRealModel,
  });
}

/// خطوة "Final Pipeline" الكاملة من البرومبت — من الصورة الأصلية لحد
/// المخرج النهائي، بالكامل offline. كل خطوة بتنادي callback [onStep]
/// عشان شاشة الـ Processing تعرض الحالة الحالية للمستخدم.
class EnhancementPipeline {
  final ImageAnalysisService _analysisService = ImageAnalysisService();
  final FaceProtectionService _faceService = FaceProtectionService();
  final EnhancementService _enhancementService = EnhancementService();
  final BlendService _blendService = BlendService();

  Future<PipelineResult> run({
    required File imageFile,
    required EnhancementSettings settings,
    void Function(PipelineStep step)? onStep,
  }) async {
    // --- Step 1: Input + إنشاء نسخة أصلية غير قابلة للتعديل ---
    final originalBytes = await imageFile.readAsBytes();
    final decoded = img.decodeImage(originalBytes);
    if (decoded == null) {
      throw const FormatException('تعذّر قراءة الصورة — تأكد إن الصيغة JPG/PNG/WEBP');
    }
    final immutableOriginal = img.Image.from(decoded); // نسخة احتياطية ثابتة

    // --- Step 2 & 3: Analysis + Quality Classification ---
    onStep?.call(PipelineStep.analyzing);
    final analysis = _analysisService.analyze(immutableOriginal);

    // --- Step 4: Face Detection (on-device) ---
    onStep?.call(PipelineStep.protectingIdentity);
    final faceRegions = await _faceService.detectFaces(
      imageFile: imageFile,
      sourceWidth: decoded.width,
      sourceHeight: decoded.height,
      pixelWidth: decoded.width,
      pixelHeight: decoded.height,
    );

    // --- Step 5: Main Restoration (denoise + إعداد للـ deblur) ---
    onStep?.call(PipelineStep.restoringDetails);
    final profile = analysis.profile;
    final denoiseAmount =
        (profile.denoiseStrength * settings.denoiseMultiplier).clamp(0.0, 1.0);
    var working = _enhancementService.denoise(immutableOriginal, denoiseAmount);

    // --- Step 6/8: Face-aware Super Resolution (offline model, tile-based) ---
    onStep?.call(PipelineStep.upscaling);
    final modelReady = await _enhancementService.ensureModelLoaded();
    final scaleFactor = settings.output == OutputMode.fourK
        ? _enhancementService.computeScaleFactor(analysis)
        : 1;

    img.Image upscaled;
    if (scaleFactor > 1) {
      upscaled = await _enhancementService.superResolve(
        working,
        modelScaleFactor: scaleFactor,
      );
    } else {
      upscaled = working;
    }

    // --- Step: Natural Sharpening (بعد التكبير عشان التفاصيل تبان صح) ---
    onStep?.call(PipelineStep.enhancingTextures);
    final sharpenAmount = profile.detailRecovery * 0.4; // سقف أمان
    upscaled = _enhancementService.naturalSharpen(upscaled, sharpenAmount);

    // --- Step 9/10: Validation + Confidence Blending مع الأصل ---
    onStep?.call(PipelineStep.finalizing);
    final originalResized = scaleFactor > 1
        ? img.copyResize(
            immutableOriginal,
            width: upscaled.width,
            height: upscaled.height,
            interpolation: img.Interpolation.cubic,
          )
        : immutableOriginal;

    final scaledFaceRegions = faceRegions
        .map((r) => ProtectedFaceRegion(
              (r.left * scaleFactor),
              (r.top * scaleFactor),
              (r.right * scaleFactor),
              (r.bottom * scaleFactor),
            ))
        .toList();

    var blended = _blendService.blend(
      original: originalResized,
      enhanced: upscaled,
      settings: settings,
      faceRegions: scaledFaceRegions,
    );

    // فحص تشابه إضافي مرة واحدة على الوجوه (مش loop) — لو في وجه اتغيّر
    // كتير، بنزوّد نسبة الحفاظ على الأصل جواه بس.
    if (scaledFaceRegions.isNotEmpty) {
      blended = _blendService.reinforceIfSuspicious(
        original: originalResized,
        blended: blended,
        faceRegions: scaledFaceRegions,
        similarityOf: (region) => _faceService.structuralSimilarity(
          originalResized,
          blended,
          region,
        ),
      );
    }

    // --- Step 11: Export ---
    final enhancedPng = Uint8List.fromList(img.encodePng(blended));
    final originalPng = Uint8List.fromList(img.encodePng(immutableOriginal));

    onStep?.call(PipelineStep.done);

    return PipelineResult(
      originalPngBytes: originalPng,
      enhancedPngBytes: enhancedPng,
      analysis: analysis,
      usedRealModel: modelReady && scaleFactor > 1,
    );
  }

  void dispose() {
    _faceService.dispose();
    _enhancementService.dispose();
  }
}
