import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart' show compute;
import 'package:image/image.dart' as img;

import '../core/constants.dart';
import '../core/ai_provider.dart';
import '../models/image_analysis_result.dart';
import 'api_key_store.dart';
import 'image_analysis_service.dart';
import 'face_protection_service.dart';
import 'enhancement_service.dart';
import 'blend_service.dart';
import 'remote_enhancement_service.dart';

enum PipelineStep {
  analyzing,
  restoringDetails,
  protectingIdentity,
  enhancingTextures,
  upscaling,
  finalizing,
  done,
}

class PipelineResult {
  final Uint8List originalPngBytes;
  final Uint8List enhancedPngBytes;
  final ImageAnalysisResult analysis;
  final bool usedRealModel; // true = تم التحسين فعليًا أونلاين (مش fallback)

  const PipelineResult({
    required this.originalPngBytes,
    required this.enhancedPngBytes,
    required this.analysis,
    required this.usedRealModel,
  });
}

/// الأوركستريتور الكامل. الجزء التقيل (فك التشفير، التنعيم، الشحذ،
/// الدمج، والتكبير الاحتياطي) بيتنفّذ بالكامل جوه Isolate منفصل عن
/// طريق compute()، فواجهة المستخدم تفضل سلسة وماتعلقش أثناء المعالجة —
/// مهما كانت الصورة كبيرة. كشف الوجوه (ML Kit) وقراءة مفتاح الـ API
/// هما الحاجات الوحيدة اللي لازم تحصل على الـ isolate الرئيسي (لأنها
/// محتاجة قنوات التواصل مع النظام)، وبتحصل *قبل* ما نبعت الشغل التقيل.
class EnhancementPipeline {
  final FaceProtectionService _faceService = FaceProtectionService();
  final ApiKeyStore _apiKeyStore = ApiKeyStore();

  Future<PipelineResult> run({
    required File imageFile,
    required EnhancementSettings settings,
    void Function(PipelineStep step)? onStep,
  }) async {
    onStep?.call(PipelineStep.analyzing);
    final originalBytes = await imageFile.readAsBytes();

    final decodedForFaces = img.decodeImage(originalBytes);
    if (decodedForFaces == null) {
      throw const FormatException(
          'تعذّر قراءة الصورة — تأكد إن الصيغة JPG/PNG/WEBP');
    }

    // كشف الوجوه لازم يحصل هنا على الـ isolate الرئيسي (ML Kit بيستخدم
    // قناة تواصل مع النظام مش متاحة جوه compute()).
    onStep?.call(PipelineStep.protectingIdentity);
    final faceRegions = await _faceService.detectFaces(
      imageFile: imageFile,
      sourceWidth: decodedForFaces.width,
      sourceHeight: decodedForFaces.height,
      pixelWidth: decodedForFaces.width,
      pixelHeight: decodedForFaces.height,
    );

    // نفس الحال لمفتاح الـ API والمزوّد المختار (shared_preferences محتاج
    // قناة تواصل، فلازم يحصل هنا على الـ isolate الرئيسي).
    final selectedProvider = await _apiKeyStore.readSelectedProvider();
    final apiKey = await _apiKeyStore.readKey(selectedProvider);
    final hfSpaceId = await _apiKeyStore.readHfSpace();

    onStep?.call(PipelineStep.restoringDetails);
    onStep?.call(PipelineStep.upscaling);

    // كل المعالجة التقيلة (تنعيم، نداء التحسين الأونلاين أو fallback،
    // شحذ، دمج) بتتنفّذ هنا جوه isolate منفصل بالكامل.
    final resultMap = await compute(_runHeavyEnhancement, {
      'originalBytes': originalBytes,
      'enhancement': settings.enhancement.index,
      'faceProtection': settings.faceProtection.index,
      'noiseReduction': settings.noiseReduction.index,
      'output': settings.output.index,
      'provider': selectedProvider.index,
      'apiKey': apiKey,
      'hfSpaceId': hfSpaceId,
      'faceRegions': faceRegions
          .map((r) => {
                'left': r.left,
                'top': r.top,
                'right': r.right,
                'bottom': r.bottom,
              })
          .toList(),
    });

    onStep?.call(PipelineStep.enhancingTextures);
    onStep?.call(PipelineStep.finalizing);

    final analysis = ImageAnalysisResult(
      width: resultMap['width'] as int,
      height: resultMap['height'] as int,
      blurScore: 0,
      noiseScore: 0,
      averageBrightness: 128,
      dynamicRange: 0,
      qualityClass: ImageQualityClass.values[resultMap['qualityClass'] as int],
    );

    onStep?.call(PipelineStep.done);

    return PipelineResult(
      originalPngBytes: resultMap['originalBytes'] as Uint8List,
      enhancedPngBytes: resultMap['enhancedBytes'] as Uint8List,
      analysis: analysis,
      usedRealModel: resultMap['usedRemote'] as bool,
    );
  }

  void dispose() {
    _faceService.dispose();
  }
}

// ---------------------------------------------------------------------
// الدالة دي لازم تفضل top-level (مش method جوه كلاس) عشان compute()
// يقدر يبعتها لـ isolate منفصل. كل حاجة بتستخدمها هنا Dart خالص أو
// نداءات شبكة (http) — مفيش أي platform channel، فآمنة 100% جوه isolate.
// ---------------------------------------------------------------------
Future<Map<String, dynamic>> _runHeavyEnhancement(
  Map<String, dynamic> args,
) async {
  final originalBytes = args['originalBytes'] as Uint8List;
  final provider = AiProvider.values[args['provider'] as int];
  final apiKey = args['apiKey'] as String;
  final hfSpaceId = args['hfSpaceId'] as String;
  final faceRegionsRaw = args['faceRegions'] as List;

  final settings = EnhancementSettings(
    enhancement: EnhancementLevel.values[args['enhancement'] as int],
    faceProtection: FaceProtectionLevel.values[args['faceProtection'] as int],
    noiseReduction: NoiseReductionLevel.values[args['noiseReduction'] as int],
    output: OutputMode.values[args['output'] as int],
  );

  final analysisService = ImageAnalysisService();
  final enhancementService = EnhancementService();
  final blendService = BlendService();
  final remoteService = RemoteEnhancementService();

  final decoded = img.decodeImage(originalBytes);
  if (decoded == null) {
    throw const FormatException('تعذّر قراءة الصورة داخل المعالجة');
  }
  final immutableOriginal = img.Image.from(decoded);
  final analysis = analysisService.analyze(immutableOriginal);
  final profile = analysis.profile;

  // --- Denoise ---
  final denoiseAmount =
      (profile.denoiseStrength * settings.denoiseMultiplier).clamp(0.0, 1.0);
  final working = enhancementService.denoise(immutableOriginal, denoiseAmount);

  // --- Super-Resolution: أونلاين الأول، وبعدين fallback محلي ---
  final scaleFactor = settings.output == OutputMode.fourK
      ? enhancementService.computeScaleFactor(analysis)
      : 1;

  img.Image upscaled;
  bool usedRemote = false;

  if (scaleFactor > 1) {
    Uint8List? remoteBytes;
    if (provider.worksWithoutKey || apiKey.trim().isNotEmpty) {
      final workingPng = Uint8List.fromList(img.encodePng(working));
      remoteBytes = await remoteService.upscale(
        imageBytes: workingPng,
        provider: provider,
        apiKey: apiKey,
        hfSpaceId: hfSpaceId,
        scale: scaleFactor,
      );
    }

    if (remoteBytes != null) {
      final remoteDecoded = img.decodeImage(remoteBytes);
      if (remoteDecoded != null) {
        upscaled = remoteDecoded;
        usedRemote = true;
      } else {
        upscaled = enhancementService.localUpscale(working, scaleFactor);
      }
    } else {
      upscaled = enhancementService.localUpscale(working, scaleFactor);
    }
  } else {
    upscaled = working;
  }

  // --- Natural Sharpening ---
  final sharpenAmount = profile.detailRecovery * 0.4;
  upscaled = enhancementService.naturalSharpen(upscaled, sharpenAmount);

  // --- Confidence Blending مع الأصل ---
  final originalResized =
      (upscaled.width != immutableOriginal.width ||
              upscaled.height != immutableOriginal.height)
          ? img.copyResize(
              immutableOriginal,
              width: upscaled.width,
              height: upscaled.height,
              interpolation: img.Interpolation.cubic,
            )
          : immutableOriginal;

  final effectiveScaleX = immutableOriginal.width > 0
      ? upscaled.width / immutableOriginal.width
      : 1.0;
  final effectiveScaleY = immutableOriginal.height > 0
      ? upscaled.height / immutableOriginal.height
      : 1.0;

  final faceRegions = faceRegionsRaw.map((raw) {
    final m = raw as Map;
    return ProtectedFaceRegion(
      ((m['left'] as int) * effectiveScaleX).round(),
      ((m['top'] as int) * effectiveScaleY).round(),
      ((m['right'] as int) * effectiveScaleX).round(),
      ((m['bottom'] as int) * effectiveScaleY).round(),
    );
  }).toList();

  var blended = blendService.blend(
    original: originalResized,
    enhanced: upscaled,
    settings: settings,
    faceRegions: faceRegions,
  );

  if (faceRegions.isNotEmpty) {
    blended = blendService.reinforceIfSuspicious(
      original: originalResized,
      blended: blended,
      faceRegions: faceRegions,
      similarityOf: (region) =>
          _structuralSimilarity(originalResized, blended, region),
    );
  }

  final enhancedPng = Uint8List.fromList(img.encodePng(blended));
  final originalPng = Uint8List.fromList(img.encodePng(immutableOriginal));

  return {
    'enhancedBytes': enhancedPng,
    'originalBytes': originalPng,
    'width': analysis.width,
    'height': analysis.height,
    'qualityClass': analysis.qualityClass.index,
    'usedRemote': usedRemote,
  };
}

/// نسخة Dart خالصة من فحص التشابه (بدون أي اعتماد على ML Kit) — آمنة
/// 100% جوه الـ isolate. نفس منطق FaceProtectionService.structuralSimilarity.
double _structuralSimilarity(
  img.Image original,
  img.Image enhanced,
  ProtectedFaceRegion region,
) {
  double diffSum = 0;
  int count = 0;
  for (int y = region.top; y < region.bottom; y += 2) {
    for (int x = region.left; x < region.right; x += 2) {
      if (x >= original.width ||
          y >= original.height ||
          x >= enhanced.width ||
          y >= enhanced.height) {
        continue;
      }
      final a = original.getPixel(x, y).luminance.toDouble();
      final b = enhanced.getPixel(x, y).luminance.toDouble();
      diffSum += (a - b).abs();
      count++;
    }
  }
  if (count == 0) return 1.0;
  final avgDiff = diffSum / count;
  return (1.0 - (avgDiff / 255.0)).clamp(0.0, 1.0);
}
