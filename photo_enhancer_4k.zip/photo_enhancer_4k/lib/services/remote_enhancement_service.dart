import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;

import '../core/ai_provider.dart';

/// خطوة "Final Upscaling" أونلاين — بتوجّه النداء لأي مزوّد المستخدم
/// اختاره (Hugging Face المجاني، أو Replicate/OpenAI/Gemini بمفتاح
/// المستخدم الشخصي). أي فشل (مفيش مفتاح، مفيش نت، تايم آوت، الخدمة
/// واقفة) بيرجّع null بهدوء عشان الـ pipeline يكمل بتكبير محلي بدل ما
/// يوقف بالكامل.
class RemoteEnhancementService {
  Future<Uint8List?> upscale({
    required Uint8List imageBytes,
    required AiProvider provider,
    required String apiKey,
    required String hfSpaceId,
    int scale = 4,
  }) async {
    try {
      switch (provider) {
        case AiProvider.huggingFace:
          return await _upscaleHuggingFace(
            imageBytes: imageBytes,
            spaceId: hfSpaceId.trim().isEmpty
                ? defaultHuggingFaceSpace
                : hfSpaceId.trim(),
            token: apiKey,
            scale: scale,
          );
        case AiProvider.replicate:
          if (apiKey.trim().isEmpty) return null;
          return await _upscaleReplicate(
            imageBytes: imageBytes,
            apiToken: apiKey,
            scale: scale,
          );
        case AiProvider.openAI:
          if (apiKey.trim().isEmpty) return null;
          return await _upscaleOpenAI(imageBytes: imageBytes, apiKey: apiKey);
        case AiProvider.gemini:
          if (apiKey.trim().isEmpty) return null;
          return await _upscaleGemini(imageBytes: imageBytes, apiKey: apiKey);
      }
    } catch (_) {
      return null;
    }
  }

  // ---------------------------------------------------------------------
  // Hugging Face — Space مفتوح المصدر (Real-ESRGAN)، شغال بدون مفتاح
  // شخصي (بحدود استخدام عامة أقل، وبإمكانية تحسينها بمفتاح مجاني).
  // ---------------------------------------------------------------------
  Future<Uint8List?> _upscaleHuggingFace({
    required Uint8List imageBytes,
    required String spaceId,
    required String token,
    required int scale,
  }) async {
    final slug = spaceId.replaceAll('/', '-').toLowerCase();
    final baseUrl = 'https://$slug.hf.space';
    final sizeArg = scale <= 2 ? '2x' : '4x';

    final headers = {
      'Content-Type': 'application/json',
      if (token.trim().isNotEmpty) 'Authorization': 'Bearer ${token.trim()}',
    };

    final dataUri = 'data:image/png;base64,${base64Encode(imageBytes)}';

    final createResp = await http
        .post(
          Uri.parse('$baseUrl/gradio_api/call/predict'),
          headers: headers,
          body: jsonEncode({
            'data': [dataUri, sizeArg],
          }),
        )
        .timeout(const Duration(seconds: 12));

    if (createResp.statusCode != 200 && createResp.statusCode != 202) {
      return null;
    }

    final created = jsonDecode(createResp.body) as Map<String, dynamic>;
    final eventId = created['event_id'] as String?;
    if (eventId == null) return null;

    final resultResp = await http
        .get(
          Uri.parse('$baseUrl/gradio_api/call/predict/$eventId'),
          headers: headers,
        )
        .timeout(const Duration(seconds: 30));

    if (resultResp.statusCode != 200) return null;

    // الرد بصيغة SSE: أسطر "event: ..." و"data: [...]" — بنلاقي آخر
    // سطر "data:" فيه الناتج الفعلي.
    final lines = resultResp.body.split('\n');
    String? lastDataLine;
    for (final line in lines) {
      if (line.startsWith('data:')) {
        lastDataLine = line.substring(5).trim();
      }
    }
    if (lastDataLine == null || lastDataLine.isEmpty) return null;

    final decoded = jsonDecode(lastDataLine);
    if (decoded is! List || decoded.isEmpty) return null;

    return await _extractImageBytes(decoded.first, baseUrl);
  }

  /// مخرج صورة Gradio بيرجع بأشكال مختلفة حسب النسخة: string base64،
  /// أو Map فيه 'url'، أو Map فيه 'path' بس.
  Future<Uint8List?> _extractImageBytes(dynamic item, String baseUrl) async {
    if (item is String) {
      if (item.startsWith('data:image')) {
        final b64 = item.split(',').last;
        return base64Decode(b64);
      }
      if (item.startsWith('http')) {
        final r = await http.get(Uri.parse(item)).timeout(const Duration(seconds: 40));
        return r.statusCode == 200 ? r.bodyBytes : null;
      }
      return null;
    }
    if (item is Map) {
      final url = item['url'] as String?;
      if (url != null) {
        final r = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 40));
        return r.statusCode == 200 ? r.bodyBytes : null;
      }
      final path = item['path'] as String?;
      if (path != null) {
        final fullUrl = '$baseUrl/file=$path';
        final r = await http.get(Uri.parse(fullUrl)).timeout(const Duration(seconds: 40));
        return r.statusCode == 200 ? r.bodyBytes : null;
      }
    }
    return null;
  }

  // ---------------------------------------------------------------------
  // Replicate — Real-ESRGAN مستضاف، محتاج مفتاح شخصي.
  // ---------------------------------------------------------------------
  Future<Uint8List?> _upscaleReplicate({
    required Uint8List imageBytes,
    required String apiToken,
    required int scale,
  }) async {
    const predictionsUrl = 'https://api.replicate.com/v1/predictions';
    const realEsrganVersion =
        'f121d640bd286e1fdc67f9799164c1d5be36ff74576ee11c803ae5b665dd46a';

    final dataUri = 'data:image/png;base64,${base64Encode(imageBytes)}';

    final createResponse = await http
        .post(
          Uri.parse(predictionsUrl),
          headers: {
            'Authorization': 'Token ${apiToken.trim()}',
            'Content-Type': 'application/json',
            'Prefer': 'wait=1',
          },
          body: jsonEncode({
            'version': realEsrganVersion,
            'input': {'image': dataUri, 'scale': scale, 'face_enhance': false},
          }),
        )
        .timeout(const Duration(seconds: 15));

    if (createResponse.statusCode != 200 && createResponse.statusCode != 201) {
      return null;
    }

    var data = jsonDecode(createResponse.body) as Map<String, dynamic>;
    final getUrl = (data['urls'] as Map?)?['get'] as String?;
    if (getUrl == null) return null;

    final deadline = DateTime.now().add(const Duration(seconds: 60));
    while (DateTime.now().isBefore(deadline)) {
      final status = data['status'] as String?;
      if (status == 'succeeded') {
        final output = data['output'];
        final outUrl = output is List
            ? (output.isNotEmpty ? output.first as String? : null)
            : output as String?;
        if (outUrl == null) return null;
        final imgResp =
            await http.get(Uri.parse(outUrl)).timeout(const Duration(seconds: 40));
        return imgResp.statusCode == 200 ? imgResp.bodyBytes : null;
      }
      if (status == 'failed' || status == 'canceled') return null;

      await Future.delayed(const Duration(seconds: 2));
      final poll = await http
          .get(Uri.parse(getUrl),
              headers: {'Authorization': 'Token ${apiToken.trim()}'})
          .timeout(const Duration(seconds: 15));
      if (poll.statusCode != 200) continue;
      data = jsonDecode(poll.body) as Map<String, dynamic>;
    }
    return null;
  }

  // ---------------------------------------------------------------------
  // OpenAI — images/edits (gpt-image-1)، محتاج مفتاح شخصي.
  // ---------------------------------------------------------------------
  Future<Uint8List?> _upscaleOpenAI({
    required Uint8List imageBytes,
    required String apiKey,
  }) async {
    final uri = Uri.parse('https://api.openai.com/v1/images/edits');
    final request = http.MultipartRequest('POST', uri)
      ..headers['Authorization'] = 'Bearer ${apiKey.trim()}'
      ..fields['model'] = 'gpt-image-1'
      ..fields['prompt'] =
          'Enhance this photo to higher resolution and clarity while '
          'preserving the exact identity, faces, proportions, colors, '
          'background and composition. Do not invent new details or change '
          'anything about who or what is in the photo.'
      ..files.add(http.MultipartFile.fromBytes(
        'image',
        imageBytes,
        filename: 'input.png',
      ));

    final streamed = await request.send().timeout(const Duration(seconds: 60));
    final response = await http.Response.fromStream(streamed);
    if (response.statusCode != 200) return null;

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final items = data['data'] as List?;
    if (items == null || items.isEmpty) return null;
    final b64 = (items.first as Map)['b64_json'] as String?;
    if (b64 == null) return null;
    return base64Decode(b64);
  }

  // ---------------------------------------------------------------------
  // Google Gemini — generateContent مع صورة كمخرج، محتاج مفتاح شخصي.
  // ---------------------------------------------------------------------
  Future<Uint8List?> _upscaleGemini({
    required Uint8List imageBytes,
    required String apiKey,
  }) async {
    final uri = Uri.parse(
      'https://generativelanguage.googleapis.com/v1beta/models/'
      'gemini-2.5-flash-image:generateContent?key=${apiKey.trim()}',
    );

    final response = await http
        .post(
          uri,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'contents': [
              {
                'parts': [
                  {
                    'text':
                        'Enhance this photo to higher resolution and clarity '
                        'while preserving the exact identity, faces, '
                        'proportions, colors, background and composition. '
                        'Do not invent new details or change anything about '
                        'who or what is in the photo.'
                  },
                  {
                    'inline_data': {
                      'mime_type': 'image/png',
                      'data': base64Encode(imageBytes),
                    }
                  },
                ],
              },
            ],
          }),
        )
        .timeout(const Duration(seconds: 45));

    if (response.statusCode != 200) return null;

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final candidates = data['candidates'] as List?;
    if (candidates == null || candidates.isEmpty) return null;
    final parts = (candidates.first['content']?['parts']) as List?;
    if (parts == null) return null;

    for (final part in parts) {
      final inline = (part as Map)['inline_data'] ?? part['inlineData'];
      if (inline is Map) {
        final b64 = inline['data'] as String?;
        if (b64 != null) return base64Decode(b64);
      }
    }
    return null;
  }
}
