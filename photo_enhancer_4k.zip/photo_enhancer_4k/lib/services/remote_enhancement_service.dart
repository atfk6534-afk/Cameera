import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;

/// خطوة "Final Upscaling" أونلاين — بتستبدل الموديل المحلي (tflite) بنداء
/// لخدمة Replicate (Real-ESRGAN) عبر الإنترنت. الفكرة: نرفع الصورة، نستنى
/// المعالجة، ننزّل النتيجة. أي فشل (مفيش مفتاح، مفيش نت، تايم آوت) بيرجّع
/// null بهدوء عشان الـ pipeline يكمل بتكبير محلي بدل ما يوقف بالكامل.
///
/// المفتاح: احصل عليه من https://replicate.com/account/api-tokens
/// وحطه في شاشة الإعدادات داخل التطبيق (بيتخزّن على الجهاز فقط).
class RemoteEnhancementService {
  static const _predictionsUrl = 'https://api.replicate.com/v1/predictions';

  /// إصدار موديل Real-ESRGAN على Replicate. لو النموذج اتحدّث ومبقاش
  /// شغال، دوّر على "real-esrgan" في replicate.com وحدّث الـ hash ده.
  static const _realEsrganVersion =
      'f121d640bd286e1fdc67f9799164c1d5be36ff74576ee11c803ae5b665dd46a';

  Future<Uint8List?> upscale({
    required Uint8List imageBytes,
    required String apiToken,
    int scale = 4,
    Duration timeout = const Duration(seconds: 90),
  }) async {
    final token = apiToken.trim();
    if (token.isEmpty) return null;

    try {
      final dataUri = 'data:image/png;base64,${base64Encode(imageBytes)}';

      final createResponse = await http
          .post(
            Uri.parse(_predictionsUrl),
            headers: {
              'Authorization': 'Token $token',
              'Content-Type': 'application/json',
              'Prefer': 'wait=1',
            },
            body: jsonEncode({
              'version': _realEsrganVersion,
              'input': {
                'image': dataUri,
                'scale': scale,
                'face_enhance': false,
              },
            }),
          )
          .timeout(const Duration(seconds: 25));

      if (createResponse.statusCode != 200 &&
          createResponse.statusCode != 201) {
        return null;
      }

      var data = jsonDecode(createResponse.body) as Map<String, dynamic>;
      final getUrl = (data['urls'] as Map?)?['get'] as String?;
      if (getUrl == null) return null;

      final deadline = DateTime.now().add(timeout);
      while (DateTime.now().isBefore(deadline)) {
        final status = data['status'] as String?;

        if (status == 'succeeded') {
          final output = data['output'];
          final outUrl = output is List
              ? (output.isNotEmpty ? output.first as String? : null)
              : output as String?;
          if (outUrl == null) return null;

          final imgResp = await http
              .get(Uri.parse(outUrl))
              .timeout(const Duration(seconds: 40));
          if (imgResp.statusCode == 200) return imgResp.bodyBytes;
          return null;
        }

        if (status == 'failed' || status == 'canceled') {
          return null;
        }

        await Future.delayed(const Duration(seconds: 2));
        final poll = await http
            .get(Uri.parse(getUrl), headers: {'Authorization': 'Token $token'})
            .timeout(const Duration(seconds: 15));
        if (poll.statusCode != 200) continue;
        data = jsonDecode(poll.body) as Map<String, dynamic>;
      }

      return null; // انتهى الوقت المسموح من غير نتيجة
    } catch (_) {
      // أي مشكلة شبكة/تايم آوت/فورمات غير متوقع — نرجع null بهدوء
      // ونسيب الـ pipeline يكمل بالـ fallback المحلي.
      return null;
    }
  }
}
