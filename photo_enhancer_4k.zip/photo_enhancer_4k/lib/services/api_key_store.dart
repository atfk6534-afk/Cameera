import 'package:shared_preferences/shared_preferences.dart';

/// تخزين مفتاح الـ API الخاص بخدمة التحسين الأونلاين (Replicate) محليًا
/// على الجهاز. لو المستخدم مسيبهوش فاضي، الـ pipeline بيرجع تلقائيًا
/// للتكبير المحلي (fallback) من غير أي خطأ.
class ApiKeyStore {
  static const _key = 'replicate_api_token';

  Future<String> read() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_key) ?? '';
    } catch (_) {
      return '';
    }
  }

  Future<void> save(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, token.trim());
  }
}
