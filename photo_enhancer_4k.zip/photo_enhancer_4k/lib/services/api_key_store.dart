import 'package:shared_preferences/shared_preferences.dart';

import '../core/ai_provider.dart';

/// تخزين مفتاح API لكل مزوّد على حدة + المزوّد المختار حاليًا، محليًا
/// على الجهاز بس (مفيش أي مفتاح بيتبعت أو يتخزّن في الكود نفسه).
class ApiKeyStore {
  static const _selectedProviderKey = 'selected_ai_provider';

  String _keyFor(AiProvider provider) => 'api_key_${provider.name}';

  Future<AiProvider> readSelectedProvider() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final idx = prefs.getInt(_selectedProviderKey);
      if (idx == null || idx < 0 || idx >= AiProvider.values.length) {
        return AiProvider.huggingFace;
      }
      return AiProvider.values[idx];
    } catch (_) {
      return AiProvider.huggingFace;
    }
  }

  Future<void> saveSelectedProvider(AiProvider provider) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_selectedProviderKey, provider.index);
  }

  Future<String> readKey(AiProvider provider) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_keyFor(provider)) ?? '';
    } catch (_) {
      return '';
    }
  }

  Future<void> saveKey(AiProvider provider, String key) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyFor(provider), key.trim());
  }

  static const _hfSpaceKey = 'hf_space_id';

  Future<String> readHfSpace() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_hfSpaceKey) ?? defaultHuggingFaceSpace;
    } catch (_) {
      return defaultHuggingFaceSpace;
    }
  }

  Future<void> saveHfSpace(String spaceId) async {
    final prefs = await SharedPreferences.getInstance();
    final trimmed = spaceId.trim();
    await prefs.setString(
        _hfSpaceKey, trimmed.isEmpty ? defaultHuggingFaceSpace : trimmed);
  }

  /// بيرجع كل المفاتيح المخزّنة دفعة واحدة (مفيد عشان نبعتها كلها لل
  /// isolate التقيل مرة واحدة بدل نداءات platform channel متكررة).
  Future<Map<String, String>> readAllKeys() async {
    final result = <String, String>{};
    for (final p in AiProvider.values) {
      result[p.name] = await readKey(p);
    }
    return result;
  }
}
