import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

import '../core/constants.dart';
import 'processing_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ImagePicker _picker = ImagePicker();
  EnhancementSettings _settings = const EnhancementSettings();
  bool _busy = false;

  Future<void> _captureAndGo() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final XFile? file = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 100,
      );
      if (file == null || !mounted) return;
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => ProcessingScreen(
            imageFile: File(file.path),
            settings: _settings,
          ),
        ),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _pickAndGo() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      // على Android 13+ و iOS، image_picker بيتعامل مع صلاحيات الصور بنفسه
      // في أغلب الحالات، بس بنطلب الصلاحية يدويًا كـ fail-safe لبعض الأجهزة
      // اللي محتاجة إذن صريح قبل ما تفتح المعرض.
      if (Platform.isAndroid) {
        await Permission.photos.request();
      }

      final XFile? file = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 100, // مانضغطش الصورة هنا، الضغط بيتم داخل الـ pipeline بوعي
      );
      if (file == null || !mounted) return;

      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => ProcessingScreen(
            imageFile: File(file.path),
            settings: _settings,
          ),
        ),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('4K Photo Enhancer')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 104,
                height: 104,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF4F46E5), Color(0xFF06B6D4)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: const [
                    BoxShadow(
                      blurRadius: 24,
                      offset: Offset(0, 12),
                      color: Color(0x334F46E5),
                    ),
                  ],
                ),
                child: const Icon(Icons.auto_awesome, size: 52, color: Colors.white),
              ),
              const SizedBox(height: 20),
              const Text(
                'حسّن صورك بذكاء… محليًا وبجودة 4K',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
              const SizedBox(height: 4),
              const Text(
                'يعمل بالكامل بدون إنترنت',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _busy ? null : _captureAndGo,
                  icon: const Icon(Icons.camera_alt),
                  label: const Text('التقاط صورة وتحسينها'),
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: _busy ? null : _pickAndGo,
                  icon: const Icon(Icons.photo_library_outlined),
                  label: const Text('تحسين صورة من الجهاز'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 17),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              TextButton.icon(
                onPressed: () => _openSettings(context),
                icon: const Icon(Icons.tune),
                label: const Text('إعدادات متقدمة'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _openSettings(BuildContext context) async {
    final result = await showModalBottomSheet<EnhancementSettings>(
      context: context,
      isScrollControlled: true,
      builder: (_) => _QuickSettingsSheet(initial: _settings),
    );
    if (result != null) setState(() => _settings = result);
  }
}

/// Advanced Settings sheet — نفس الخيارات المذكورة في البرومبت بالظبط.
class _QuickSettingsSheet extends StatefulWidget {
  final EnhancementSettings initial;
  const _QuickSettingsSheet({required this.initial});

  @override
  State<_QuickSettingsSheet> createState() => _QuickSettingsSheetState();
}

class _QuickSettingsSheetState extends State<_QuickSettingsSheet> {
  late EnhancementSettings _s = widget.initial;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('إعدادات متقدمة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            _segment<EnhancementLevel>(
              title: 'Enhancement',
              value: _s.enhancement,
              labels: const {
                EnhancementLevel.natural: 'Natural',
                EnhancementLevel.balanced: 'Balanced',
                EnhancementLevel.strong: 'Strong',
              },
              onChanged: (v) => setState(() => _s = _s.copyWith(enhancement: v)),
            ),
            _segment<FaceProtectionLevel>(
              title: 'Face Protection',
              value: _s.faceProtection,
              labels: const {
                FaceProtectionLevel.maximum: 'Maximum',
                FaceProtectionLevel.high: 'High',
                FaceProtectionLevel.standard: 'Standard',
              },
              onChanged: (v) => setState(() => _s = _s.copyWith(faceProtection: v)),
            ),
            _segment<NoiseReductionLevel>(
              title: 'Noise Reduction',
              value: _s.noiseReduction,
              labels: const {
                NoiseReductionLevel.low: 'Low',
                NoiseReductionLevel.medium: 'Medium',
                NoiseReductionLevel.high: 'High',
              },
              onChanged: (v) => setState(() => _s = _s.copyWith(noiseReduction: v)),
            ),
            _segment<OutputMode>(
              title: 'Output',
              value: _s.output,
              labels: const {
                OutputMode.fourK: '4K',
                OutputMode.originalAspect: 'Original Aspect Ratio',
              },
              onChanged: (v) => setState(() => _s = _s.copyWith(output: v)),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => Navigator.of(context).pop(_s),
                child: const Text('حفظ'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _segment<T>({
    required String title,
    required T value,
    required Map<T, String> labels,
    required ValueChanged<T> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            children: labels.entries.map((e) {
              final selected = e.key == value;
              return ChoiceChip(
                label: Text(e.value),
                selected: selected,
                onSelected: (_) => onChanged(e.key),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
