import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

import '../core/constants.dart';
import '../services/api_key_store.dart';
import 'processing_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ImagePicker _picker = ImagePicker();
  final ApiKeyStore _apiKeyStore = ApiKeyStore();
  EnhancementSettings _settings = const EnhancementSettings();
  bool _busy = false;

  Future<void> _pickFrom(ImageSource source) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      if (Platform.isAndroid) {
        if (source == ImageSource.camera) {
          await Permission.camera.request();
        } else {
          await Permission.photos.request();
        }
      }

      // مانضغطش الصورة هنا، الضغط بيتم داخل الـ pipeline بوعي
      final XFile? file = await _picker.pickImage(
        source: source,
        imageQuality: 100,
      );
      if (file == null || !mounted) return;

      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => ProcessingScreen(
            imageFile: File(file.path),
            settings: _settings,
          ),
        ),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('4K Photo Enhancer')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.auto_fix_high, size: 72),
              const SizedBox(height: 16),
              const Text(
                'حسّن صورك بشكل طبيعي وواقعي',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
              const SizedBox(height: 4),
              const Text(
                'تحسين أونلاين بجودة أعلى، مع نسخة احتياطية محلية',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              const SizedBox(height: 32),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  FilledButton.icon(
                    onPressed: _busy ? null : () => _pickFrom(ImageSource.gallery),
                    icon: _busy
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.image),
                    label: const Text('اختر صورة'),
                    style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    ),
                  ),
                  const SizedBox(width: 10),
                  OutlinedButton.icon(
                    onPressed: _busy ? null : () => _pickFrom(ImageSource.camera),
                    icon: const Icon(Icons.camera_alt),
                    label: const Text('التقط صورة'),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextButton.icon(
                onPressed: () => _openSettings(context),
                icon: const Icon(Icons.tune),
                label: const Text('إعدادات متقدمة'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _openSettings(BuildContext context) async {
    final currentToken = await _apiKeyStore.read();
    if (!context.mounted) return;
    final result = await showModalBottomSheet<EnhancementSettings>(
      context: context,
      isScrollControlled: true,
      builder: (_) => _QuickSettingsSheet(
        initial: _settings,
        initialApiToken: currentToken,
        apiKeyStore: _apiKeyStore,
      ),
    );
    if (result != null) setState(() => _settings = result);
  }
}

/// Advanced Settings sheet — نفس الخيارات المذكورة في البرومبت، بالإضافة
/// لحقل مفتاح خدمة التحسين الأونلاين.
class _QuickSettingsSheet extends StatefulWidget {
  final EnhancementSettings initial;
  final String initialApiToken;
  final ApiKeyStore apiKeyStore;

  const _QuickSettingsSheet({
    required this.initial,
    required this.initialApiToken,
    required this.apiKeyStore,
  });

  @override
  State<_QuickSettingsSheet> createState() => _QuickSettingsSheetState();
}

class _QuickSettingsSheetState extends State<_QuickSettingsSheet> {
  late EnhancementSettings _s = widget.initial;
  late final TextEditingController _tokenController =
      TextEditingController(text: widget.initialApiToken);
  bool _obscureToken = true;

  @override
  void dispose() {
    _tokenController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 20,
          bottom: 20 + MediaQuery.of(context).viewInsets.bottom,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('إعدادات متقدمة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              _segment<EnhancementLevel>(
                title: 'Enhancement',
                value: _s.enhancement,
                labels: const {
                  EnhancementLevel.natural: 'Natural',
                  EnhancementLevel.balanced: 'Balanced',
                  EnhancementLevel.strong: 'Strong',
                },
                onChanged: (v) => setState(() => _s = _s.copyWith(enhancement: v)),
              ),
              _segment<FaceProtectionLevel>(
                title: 'Face Protection',
                value: _s.faceProtection,
                labels: const {
                  FaceProtectionLevel.maximum: 'Maximum',
                  FaceProtectionLevel.high: 'High',
                  FaceProtectionLevel.standard: 'Standard',
                },
                onChanged: (v) => setState(() => _s = _s.copyWith(faceProtection: v)),
              ),
              _segment<NoiseReductionLevel>(
                title: 'Noise Reduction',
                value: _s.noiseReduction,
                labels: const {
                  NoiseReductionLevel.low: 'Low',
                  NoiseReductionLevel.medium: 'Medium',
                  NoiseReductionLevel.high: 'High',
                },
                onChanged: (v) => setState(() => _s = _s.copyWith(noiseReduction: v)),
              ),
              _segment<OutputMode>(
                title: 'Output',
                value: _s.output,
                labels: const {
                  OutputMode.fourK: '4K',
                  OutputMode.originalAspect: 'Original Aspect Ratio',
                },
                onChanged: (v) => setState(() => _s = _s.copyWith(output: v)),
              ),
              const Divider(height: 28),
              const Text('مفتاح خدمة التحسين الأونلاين',
                  style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              const Text(
                'من replicate.com/account/api-tokens — لو سبته فاضي، '
                'التطبيق هيستخدم تكبير محلي بدل الأونلاين.',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _tokenController,
                obscureText: _obscureToken,
                decoration: InputDecoration(
                  border: const OutlineInputBorder(),
                  hintText: 'r8_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
                  suffixIcon: IconButton(
                    icon: Icon(_obscureToken ? Icons.visibility : Icons.visibility_off),
                    onPressed: () => setState(() => _obscureToken = !_obscureToken),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () async {
                    await widget.apiKeyStore.save(_tokenController.text);
                    if (context.mounted) Navigator.of(context).pop(_s);
                  },
                  child: const Text('حفظ'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _segment<T>({
    required String title,
    required T value,
    required Map<T, String> labels,
    required ValueChanged<T> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            children: labels.entries.map((e) {
              final selected = e.key == value;
              return ChoiceChip(
                label: Text(e.value),
                selected: selected,
                onSelected: (_) => onChanged(e.key),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
