import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:gal/gal.dart';
import 'package:share_plus/share_plus.dart';

import '../core/constants.dart';
import '../services/enhancement_pipeline.dart';
import '../widgets/before_after_slider.dart';
import 'home_screen.dart';
import 'processing_screen.dart';

class ResultScreen extends StatefulWidget {
  final PipelineResult result;
  final EnhancementSettings settings;

  const ResultScreen({super.key, required this.result, required this.settings});

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  bool _busy = false;

  Future<File> _writeTempEnhanced() async {
    final dir = await getTemporaryDirectory();
    final file = File(
      '${dir.path}/enhanced_${DateTime.now().millisecondsSinceEpoch}.png',
    );
    await file.writeAsBytes(widget.result.enhancedPngBytes, flush: true);
    return file;
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    try {
      final hasAccess = await Gal.hasAccess();
      if (!hasAccess) {
        final granted = await Gal.requestAccess();
        if (!granted) {
          _showSnack('محتاجين إذن الوصول للمعرض عشان نحفظ الصورة');
          return;
        }
      }
      final file = await _writeTempEnhanced();
      await Gal.putImage(file.path, album: '4K Photo Enhancer');
      _showSnack('اتحفظت الصورة في المعرض ✅');
    } catch (e) {
      _showSnack('حصل خطأ أثناء الحفظ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _share() async {
    setState(() => _busy = true);
    try {
      final file = await _writeTempEnhanced();
      // ملحوظة: بنستخدم الـ API الكلاسيكي Share.shareXFiles لأنه متوافق مع
      // كل نسخ share_plus ^10.x (النسخة الأحدث SharePlus.instance.share
      // موجودة بس من share_plus 11+ ومش مضمونة تتوافر مع كل قيود pubspec).
      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'صورة اتحسّنت بـ 4K Photo Enhancer',
      );
    } catch (e) {
      _showSnack('حصل خطأ أثناء المشاركة: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _enhanceAgain() async {
    final tempFile = await _writeTempEnhanced();
    // "Enhance Again" هنا معناها إعادة التشغيل على نفس المخرج الحالي
    // كمدخل جديد — مفيدة للصور شديدة التلف اللي محتاجة أكتر من باس.
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => ProcessingScreen(imageFile: tempFile, settings: widget.settings),
      ),
    );
  }

  void _newPhoto() {
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('النتيجة'),
        actions: [
          if (!widget.result.usedRealModel)
            const Padding(
              padding: EdgeInsets.only(left: 12),
              child: Tooltip(
                message: 'موديل الـ Super-Resolution مش متاح — تم استخدام تكبير احتياطي',
                child: Icon(Icons.info_outline, color: Colors.amber),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: BeforeAfterSlider(
                  beforeBytes: widget.result.originalPngBytes,
                  afterBytes: widget.result.enhancedPngBytes,
                ),
              ),
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Wrap(
                alignment: WrapAlignment.center,
                spacing: 10,
                runSpacing: 10,
                children: [
                  FilledButton.icon(
                    onPressed: _busy ? null : _save,
                    icon: const Icon(Icons.download),
                    label: const Text('Save Image'),
                  ),
                  OutlinedButton.icon(
                    onPressed: _busy ? null : _share,
                    icon: const Icon(Icons.share),
                    label: const Text('Share'),
                  ),
                  OutlinedButton.icon(
                    onPressed: _busy ? null : _enhanceAgain,
                    icon: const Icon(Icons.replay),
                    label: const Text('Enhance Again'),
                  ),
                  TextButton.icon(
                    onPressed: _busy ? null : _newPhoto,
                    icon: const Icon(Icons.add_photo_alternate),
                    label: const Text('New Photo'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
