import 'dart:io';
import 'package:flutter/material.dart';

import '../core/constants.dart';
import '../services/enhancement_pipeline.dart';
import 'result_screen.dart';

class ProcessingScreen extends StatefulWidget {
  final File imageFile;
  final EnhancementSettings settings;

  const ProcessingScreen({
    super.key,
    required this.imageFile,
    required this.settings,
  });

  @override
  State<ProcessingScreen> createState() => _ProcessingScreenState();
}

class _ProcessingScreenState extends State<ProcessingScreen> {
  final EnhancementPipeline _pipeline = EnhancementPipeline();
  PipelineStep _current = PipelineStep.analyzing;
  double _progress = 0.08;
  String? _error;

  static const Map<PipelineStep, String> _labels = {
    PipelineStep.analyzing: 'Analyzing image...',
    PipelineStep.restoringDetails: 'Restoring details...',
    PipelineStep.protectingIdentity: 'Protecting identity...',
    PipelineStep.enhancingTextures: 'Enhancing textures...',
    PipelineStep.upscaling: 'Upscaling...',
    PipelineStep.finalizing: 'Finalizing...',
    PipelineStep.done: 'Done',
  };

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    try {
      final result = await _pipeline.run(
        imageFile: widget.imageFile,
        settings: widget.settings,
        onStep: (step) {
          if (mounted) {
            setState(() {
              _current = step;
              _progress = _progressFor(step);
            });
          }
        },
      );
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => ResultScreen(
            result: result,
            settings: widget.settings,
          ),
        ),
      );
    } catch (e) {
      // أي خطأ (صورة تالفة، موديل مش متاح، مساحة تخزين... إلخ) بيتعرض
      // بوضوح بدل ما التطبيق يقفل فجأة (تفادي "simple errors" بلا رسائل).
      if (mounted) setState(() => _error = e.toString());
    }
  }

  @override
  void dispose() {
    _pipeline.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: _error != null ? _buildError(context) : _buildProgress(),
      ),
    );
  }

  double _progressFor(PipelineStep step) {
    switch (step) {
      case PipelineStep.analyzing: return 0.10;
      case PipelineStep.protectingIdentity: return 0.22;
      case PipelineStep.restoringDetails: return 0.34;
      case PipelineStep.upscaling: return 0.70;
      case PipelineStep.enhancingTextures: return 0.88;
      case PipelineStep.finalizing: return 0.96;
      case PipelineStep.done: return 1.0;
    }
  }

  Widget _buildProgress() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: 180,
          child: LinearProgressIndicator(value: _progress),
        ),
        const SizedBox(height: 24),
        Text(
          _labels[_current] ?? '...',
          style: const TextStyle(fontSize: 16),
        ),
      ],
    );
  }

  Widget _buildError(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.error_outline, size: 48, color: Colors.redAccent),
          const SizedBox(height: 12),
          Text(
            'حصل خطأ أثناء التحسين:\n$_error',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('رجوع'),
          ),
        ],
      ),
    );
  }
}
