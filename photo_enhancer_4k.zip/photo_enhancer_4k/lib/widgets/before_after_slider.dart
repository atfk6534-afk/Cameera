import 'dart:typed_data';
import 'package:flutter/material.dart';

/// سلايدر بسيط لمقارنة "قبل/بعد" بالسحب — بدون أي باكدج خارجي إضافي.
class BeforeAfterSlider extends StatefulWidget {
  final Uint8List beforeBytes;
  final Uint8List afterBytes;

  const BeforeAfterSlider({
    super.key,
    required this.beforeBytes,
    required this.afterBytes,
  });

  @override
  State<BeforeAfterSlider> createState() => _BeforeAfterSliderState();
}

class _BeforeAfterSliderState extends State<BeforeAfterSlider> {
  double _position = 0.5; // 0 = before بالكامل, 1 = after بالكامل

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final height = constraints.maxHeight;
        final clipWidth = width * _position;

        return GestureDetector(
          onHorizontalDragUpdate: (details) {
            setState(() {
              final dx = details.localPosition.dx.clamp(0.0, width);
              _position = (dx / width).clamp(0.0, 1.0);
            });
          },
          onTapDown: (details) {
            setState(() {
              final dx = details.localPosition.dx.clamp(0.0, width);
              _position = (dx / width).clamp(0.0, 1.0);
            });
          },
          child: Stack(
            children: [
              // AFTER (تحت، كامل)
              Positioned.fill(
                child: Image.memory(widget.afterBytes, fit: BoxFit.cover),
              ),
              // BEFORE (فوق، مقصوص حسب موضع السلايدر)
              ClipRect(
                clipper: _LeftClipper(clipWidth),
                child: SizedBox(
                  width: width,
                  height: height,
                  child: Image.memory(widget.beforeBytes, fit: BoxFit.cover),
                ),
              ),
              // خط الفاصل + المقبض
              Positioned(
                left: clipWidth - 1,
                top: 0,
                bottom: 0,
                child: Container(width: 2, color: Colors.white),
              ),
              Positioned(
                left: clipWidth - 16,
                top: height / 2 - 16,
                child: Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 4),
                    ],
                  ),
                  child: const Icon(Icons.compare_arrows, size: 18, color: Colors.black87),
                ),
              ),
              const Positioned(
                left: 8,
                top: 8,
                child: _Badge('BEFORE'),
              ),
              const Positioned(
                right: 8,
                top: 8,
                child: _Badge('AFTER'),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _LeftClipper extends CustomClipper<Rect> {
  final double width;
  _LeftClipper(this.width);

  @override
  Rect getClip(Size size) => Rect.fromLTWH(0, 0, width, size.height);

  @override
  bool shouldReclip(covariant _LeftClipper oldClipper) => oldClipper.width != width;
}

class _Badge extends StatelessWidget {
  final String text;
  const _Badge(this.text);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.55),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 11)),
    );
  }
}
