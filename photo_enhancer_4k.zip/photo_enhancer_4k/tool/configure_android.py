from pathlib import Path
import re

app = Path('android/app/build.gradle.kts')
s = app.read_text()

java_block = '''compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
    isCoreLibraryDesugaringEnabled = true
}'''
if re.search(r'compileOptions\s*\{', s):
    s = re.sub(r'compileOptions\s*\{.*?\n\s*\}', java_block, s, count=1, flags=re.S)
else:
    s = s.replace('android {', 'android {\n    ' + java_block.replace('\n', '\n    '), 1)

s = re.sub(r'\n\s*kotlinOptions\s*\{.*?\n\s*\}', '', s, flags=re.S)
if 'compilerOptions' not in s:
    s += '''\n\nkotlin {
    compilerOptions {
        jvmTarget.set(
            org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
        )
    }
}
'''

if re.search(r'minSdk\s*=\s*[^\n]+', s):
    s = re.sub(r'minSdk\s*=\s*[^\n]+', 'minSdk = 24', s, count=1)
elif 'defaultConfig {' in s:
    s = s.replace('defaultConfig {', 'defaultConfig {\n        minSdk = 24', 1)

if 'desugar_jdk_libs' not in s:
    dep = '    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")'
    if 'dependencies {' in s:
        s = s.replace('dependencies {', 'dependencies {\n' + dep, 1)
    else:
        s += '\n\ndependencies {\n' + dep + '\n}\n'

app.write_text(s)

root = Path('android/build.gradle.kts')
r = root.read_text()
marker = '// PHOTO_ENHANCER_GLOBAL_JVM17_FIX'
if marker not in r:
    r += '''\n\n// PHOTO_ENHANCER_GLOBAL_JVM17_FIX
subprojects {
    tasks.withType<org.gradle.api.tasks.compile.JavaCompile>().configureEach {
        sourceCompatibility = "17"
        targetCompatibility = "17"
    }
}
'''
    root.write_text(r)

manifest = Path('android/app/src/main/AndroidManifest.xml')
m = manifest.read_text()
if 'android.permission.CAMERA' not in m:
    m = m.replace(
        '<manifest xmlns:android="http://schemas.android.com/apk/res/android">',
        '<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n    <uses-permission android:name="android.permission.CAMERA" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />',
        1,
    )
manifest.write_text(m)

Path('android/app/proguard-rules.pro').write_text(
    '-keep class ai.onnxruntime.** { *; }\n'
)
print('Android configuration applied.')
