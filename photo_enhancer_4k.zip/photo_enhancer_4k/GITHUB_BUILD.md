# GitHub build

Upload `photo_enhancer_4k.zip` to the repository root.

The workflow in `.github/workflows/build.yml` is also included inside the project
for reference, but if you are uploading this project as a ZIP-inside-repository,
copy the workflow file to the repository's `.github/workflows/build.yml`.

The workflow:
1. Extracts the ZIP.
2. Installs Java 17 using setup-java@v5.
3. Installs Flutter Stable.
4. Generates Android files only if `android/` is missing.
5. Configures only `android/app`, and explicitly aligns Java/Kotlin JVM targets to 17 without `afterEvaluate` or global `subprojects` hooks.
6. Runs pub get, analyze, tests, and release APK build.
7. Uploads the split-per-ABI APKs as an artifact.

Important: this archive does not contain a real `.tflite` super-resolution model.
Without that model, the app's safe fallback is used instead of neural SR.
