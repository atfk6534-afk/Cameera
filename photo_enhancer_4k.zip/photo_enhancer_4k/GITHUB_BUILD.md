# GitHub build

Upload `photo_enhancer_4k.zip` to the repository root.

The workflow in `.github/workflows/build.yml` is also included inside the project
for reference, but if you are uploading this project as a ZIP-inside-repository,
copy the workflow file to the repository's `.github/workflows/build.yml`.

The workflow:
1. Extracts the ZIP.
2. Installs Java 17 using setup-java@v5.
3. Installs Flutter Stable.
4. Generates Android files only if `android/` is missing.
5. Configures only `android/app`, and explicitly aligns Java/Kotlin JVM targets to 17 without `afterEvaluate` or global `subprojects` hooks.
6. Aligns JavaCompile tasks to JVM 17 for all Android subprojects (including tflite_flutter), without afterEvaluate hooks.
7. Runs pub get, analyze, tests, and release APK build.
8. Uploads the split-per-ABI APKs as an artifact.

Important: this archive does not contain a real `.tflite` super-resolution model.
Without that model, the app's safe fallback is used instead of neural SR.


## Release-build compatibility fixes

- `image_picker` is pinned to the current 1.2.x line and `image_picker_android` is overridden to `0.8.13+19`, which includes the built-in-Kotlin migration for modern AGP.
- `share_plus` is on the 13.x line, which includes built-in-Kotlin support.
- `tflite_flutter` is on 0.12.1; its Android build requires API 26+ and the workflow aligns all Android Java compile tasks to JVM 17.
- The workflow does not use `afterEvaluate`, deprecated `kotlinOptions`, or a Kotlin stdlib force.
- Gradle caches are cleared only immediately before the final release build to avoid stale plugin metadata.
