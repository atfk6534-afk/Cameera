# GitHub build

Repository layout:

```text
photo_enhancer_4k.zip
.github/workflows/build.yml
```

The workflow extracts the ZIP, generates Android if needed, downloads and verifies the open Real-ESRGAN general x4v3 ONNX model, builds the launcher icon, and produces split-per-ABI APKs.

The model is bundled into the resulting APK. Photo processing itself is offline after installation.


Note: Android-only CI disables iOS icon generation because this workflow builds APKs on Linux.
