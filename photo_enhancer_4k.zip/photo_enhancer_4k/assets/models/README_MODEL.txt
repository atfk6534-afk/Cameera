لازم تحط هنا موديل Super-Resolution شغال Offline بصيغة TensorFlow Lite (.tflite)
عشان التطبيق يشتغل بدون إنترنت خالص.

الاسم المتوقع في الكود: realesrgan_x4.tflite
(لو غيّرت الاسم، عدّل الثابت modelAssetPath في lib/core/constants.dart)

أفضل مصادر جاهزة:
1) Real-ESRGAN (x4) محوّل لـ TFLite — ابحث عن "realesrgan tflite" على GitHub،
   فيه نسخ جاهزة (مثال: xindongzhang/ESRGAN-TFLite أو Sirius-AI/... حسب توفرها وقت التحميل).
2) TensorFlow Hub: نموذج ESRGAN (esrgan-tf2) — يتحول لـ TFLite بالأمر:
   tflite_convert --saved_model_dir=esrgan_saved_model --output_file=realesrgan_x4.tflite

خطوات مهمة قبل الاستخدام:
- استخدم نسخة quantized (int8 أو float16) عشان الحجم يبقى مناسب للموبايل (عادة 5-20MB).
- تأكد إن كل الـ Ops مدعومة في TFLite Builtin Ops (من غير Select TF Ops)
  عشان ميحتاجش Flex Delegate اللي بيكبّر حجم التطبيق ويبطّئه.
- اختبر الموديل بـ input tile ثابت (مثلاً 128x128x3) عشان يتوافق مع
  التقسيم بالـ tiles في EnhancementService.

بعد ما تحط الملف الحقيقي هنا:
1) في pubspec.yaml شيل التعليق (#) من سطر:
   - assets/models/realesrgan_x4.tflite
2) شغّل: flutter pub get
