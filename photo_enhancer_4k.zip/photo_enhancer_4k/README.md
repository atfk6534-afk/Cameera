# 4K Photo Enhancer

تطبيق Flutter لتحسين الصور لجودة قريبة من 4K مع الحفاظ التام على الهوية
والملامح والخلفية والألوان (حسب الـ Master Prompt الأساسي).

## الإصدار ده (v1.2)

- **4 مزوّدين للتحسين الأونلاين، قابل للتبديل بينهم من الإعدادات:**
  - **Hugging Face** (مفتوح المصدر — Real-ESRGAN) — شغال **بدون مفتاح
    شخصي إجباري** (بحدود استخدام عامة، وممكن تحسّنها بمفتاح مجاني).
  - **Replicate**, **OpenAI**, **Google Gemini** — كل واحد بمفتاحه
    الشخصي (بيتخزن على جهاز المستخدم بس، مش في الكود، ومش بيتبعت لأي
    سيرفر تاني).
  - ⚠️ **Claude (Anthropic) مش موجود كخيار** — مالوش API لتوليد أو
    تعديل الصور أصلاً (نموذج نصوص/محادثة بس).
- **معالجة تقيلة = Isolate منفصل تمامًا عن واجهة المستخدم.** التطبيق
  مبيعلقش خالص أثناء التحسين، مهما كانت الصورة كبيرة.
- **زرار "التقط صورة"** بجانب "اختر صورة" — تصوير مباشر ثم تحسين فوري.
- **أيقونة احترافية** مولّدة تلقائيًا لكل المنصّات وقت الـ build.
- تحليل الصورة وكشف الوجوه (لحماية الهوية) لسه شغالين محليًا بالكامل.
- لو المزوّد المختار فشل (مفيش مفتاح، مفيش إنترنت، الخدمة واقفة)،
  التطبيق بيرجع تلقائيًا لتكبير محلي عالي الجودة — مش هيوقف أو يكسر.

---

## 1) فك الضغط وتجهيز المشروع

```bash
unzip photo_enhancer_4k.zip -d photo_enhancer_4k
cd photo_enhancer_4k
flutter create .
```

---

## 2) صلاحيات الوصول (كاميرا + صور)

- **Android:** انسخ محتوى `platform_config/AndroidManifest_additions.xml`
  جوه `android/app/src/main/AndroidManifest.xml` (لو بتبني محليًا — لو
  بتستخدم GitHub Actions فالـ workflow بيعمل ده تلقائيًا).
- **iOS:** انسخ محتوى `platform_config/Info_plist_additions.xml`
  جوه `ios/Runner/Info.plist`.

---

## 3) اختيار مزوّد التحسين

افتح التطبيق → إعدادات متقدمة → اختار المزوّد:

| المزوّد | محتاج مفتاح؟ | منين تجيب المفتاح |
|---|---|---|
| **Hugging Face** | لأ (اختياري لرفع الحدود) | huggingface.co/settings/tokens |
| **Replicate** | أيوه | replicate.com/account/api-tokens |
| **OpenAI** | أيوه | platform.openai.com/api-keys |
| **Google Gemini** | أيوه | aistudio.google.com/apikey |

> **ملحوظة عن Hugging Face:** الـ Space الافتراضي (`Boboiazumi/Face-Real-ESRGAN`)
> ده Space مجاني مستضاف من مطوّرين تانيين، ومش مضمون يفضل شغال للأبد
> (بالفعل النسخة الأصلية `doevent/Face-Real-ESRGAN` وقفت). لو حصل كده،
> دوّر على "real-esrgan" في huggingface.co/spaces، وحط اسم الـ Space
> الجديد (`username/space-name`) في حقل "Hugging Face Space" بالإعدادات.

> كل المفاتيح بتتخزن على جهاز المستخدم بس (shared_preferences) — مفيش
> أي مفتاح متضمّن في كود التطبيق أو بيتبعت لأي سيرفر خارجي غير المزوّد
> المختار نفسه.

---

## 4) الأيقونة

الأيقونة جاهزة في `assets/icon/icon.png` (وأيقونة adaptive منفصلة في
`assets/icon/icon_foreground.png`). بتتولّد تلقائيًا لكل الأحجام
والمنصّات عن طريق:

```bash
dart run flutter_launcher_icons
```

الأمر ده بيتشغّل تلقائيًا في الـ CI (GitHub Actions) بعد `flutter pub get`.

---

## 5) التثبيت والبناء محليًا

```bash
flutter pub get
dart run flutter_launcher_icons
flutter analyze
flutter run
```

### بناء نسخة Release

```bash
flutter build apk --release --split-per-abi
```

---

## 6) أخطاء شائعة وحلولها

| المشكلة | السبب | الحل |
|---|---|---|
| التطبيق بيرجع تكبير محلي دايمًا | مفيش مفتاح للمزوّد المختار (غير Hugging Face) أو المفتاح غلط | راجع الإعدادات المتقدمة، وتأكد إن فيه رصيد في حساب المزوّد |
| مزوّد Hugging Face بيفشل دايمًا | الـ Space المجاني وقف أو اتغيّر | دوّر على Space تاني شغال لـ real-esrgan وحدّث الاسم في الإعدادات |
| زرار "التقط صورة" مبيفتحش الكاميرا | صلاحية الكاميرا مش مضافة | تأكد من `android.permission.CAMERA` في AndroidManifest و`NSCameraUsageDescription` في Info.plist |
| التحسين الأونلاين بياخد وقت طويل | الخدمة بتاخد وقت معالجة (خصوصًا أول نداء/cold start) | ده طبيعي، فيه timeout داخلي (حتى 90 ثانية) وبعدها بيرجع للـ fallback المحلي تلقائيًا |
| الأيقونة مش بتظهر بعد التغيير | الكاش القديم للـ launcher | امسح التطبيق وأعد التثبيت، أو `flutter clean` قبل البناء |
| Crash عند فتح الكاميرا على أندرويد | صلاحية مش متطلوبة وقت التشغيل | الكود بيطلب `Permission.camera.request()` قبل الفتح — تأكد إنها مش مرفوضة من إعدادات النظام يدويًا |

---

## 7) هيكل المشروع

```
lib/
  core/
    constants.dart                 # جداول القوة حسب جودة الصورة + إعدادات المستخدم
    ai_provider.dart               # تعريف المزوّدين (Hugging Face/Replicate/OpenAI/Gemini)
  models/image_analysis_result.dart
  services/
    api_key_store.dart             # تخزين المزوّد المختار + مفتاح كل مزوّد محليًا
    image_analysis_service.dart    # تحليل + تصنيف الجودة (محلي)
    face_protection_service.dart   # كشف وجوه on-device + فحص تشابه
    enhancement_service.dart       # denoise/sharpen/fallback upscale (Dart خالص)
    remote_enhancement_service.dart # Super-Resolution أونلاين — يوجّه للمزوّد المختار
    blend_service.dart             # Confidence blending مع الأصل
    enhancement_pipeline.dart      # الأوركستريتور — الجزء التقيل شغال جوه compute()/Isolate
  screens/
    home_screen.dart               # Home Screen: اختر صورة / التقط صورة / إعدادات + اختيار المزوّد
    processing_screen.dart
    result_screen.dart
  widgets/before_after_slider.dart
assets/icon/
  icon.png                         # الأيقونة الأساسية (1024×1024)
  icon_foreground.png              # طبقة الـ Adaptive Icon (أندرويد)
```
