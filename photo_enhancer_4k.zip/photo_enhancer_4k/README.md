# 4K Photo Enhancer

تطبيق Flutter لتحسين الصور لجودة قريبة من 4K مع الحفاظ التام على الهوية
والملامح والخلفية والألوان (حسب الـ Master Prompt الأساسي).

## الإصدار ده (v1.1)

- **التحسين الحقيقي (Super-Resolution) بقى أونلاين** عن طريق خدمة
  Replicate (Real-ESRGAN)، بدل الموديل المحلي (tflite) اللي كان بيسبب
  مشاكل build كتير وبطء/علقان في التطبيق.
- **معالجة تقيلة = Isolate منفصل تمامًا عن واجهة المستخدم.** التطبيق
  مبيعلقش خالص أثناء التحسين، مهما كانت الصورة كبيرة.
- **زرار "التقط صورة"** بجانب "اختر صورة" — تصوير مباشر ثم تحسين فوري.
- **أيقونة احترافية** مولّدة تلقائيًا لكل المنصّات وقت الـ build.
- تحليل الصورة وكشف الوجوه (لحماية الهوية) لسه شغالين محليًا بالكامل
  (مش محتاجين إنترنت، وبيحصلوا بسرعة قبل ما نبعت الشغل التقيل).
- لو مفيش مفتاح API أو مفيش إنترنت، التطبيق بيرجع تلقائيًا لتكبير محلي
  عالي الجودة (fallback) — مش هيوقف أو يكسر.

---

## 1) فك الضغط وتجهيز المشروع

```bash
unzip photo_enhancer_4k.zip -d photo_enhancer_4k
cd photo_enhancer_4k
flutter create .
```

---

## 2) صلاحيات الوصول (كاميرا + صور)

- **Android:** انسخ محتوى `platform_config/AndroidManifest_additions.xml`
  جوه `android/app/src/main/AndroidManifest.xml` (لو بتبني محليًا — لو
  بتستخدم GitHub Actions فالـ workflow بيعمل ده تلقائيًا).
- **iOS:** انسخ محتوى `platform_config/Info_plist_additions.xml`
  جوه `ios/Runner/Info.plist`.

---

## 3) مفتاح خدمة التحسين الأونلاين (اختياري لكن موصى بيه)

1. اعمل حساب على [replicate.com](https://replicate.com)
2. هات مفتاح API من `replicate.com/account/api-tokens`
3. افتح التطبيق → إعدادات متقدمة → حط المفتاح في حقل "مفتاح خدمة
   التحسين الأونلاين" → حفظ

> لو سبته فاضي، التطبيق **مش هيكسر** — هيستخدم تكبير محلي (Cubic) بدل
> الأونلاين، وهيظهر تنبيه صغير في شاشة النتيجة يقولك كده.

---

## 4) الأيقونة

الأيقونة جاهزة في `assets/icon/icon.png` (وأيقونة adaptive منفصلة في
`assets/icon/icon_foreground.png`). بتتولّد تلقائيًا لكل الأحجام
والمنصّات عن طريق:

```bash
dart run flutter_launcher_icons
```

الأمر ده بيتشغّل تلقائيًا في الـ CI (GitHub Actions) بعد `flutter pub get`.

---

## 5) التثبيت والبناء محليًا

```bash
flutter pub get
dart run flutter_launcher_icons
flutter analyze
flutter run
```

### بناء نسخة Release

```bash
flutter build apk --release --split-per-abi
```

---

## 6) أخطاء شائعة وحلولها

| المشكلة | السبب | الحل |
|---|---|---|
| التطبيق بيرجع تكبير محلي دايمًا | مفيش مفتاح Replicate أو المفتاح غلط | راجع الإعدادات المتقدمة، وتأكد إن فيه رصيد في حساب Replicate |
| زرار "التقط صورة" مبيفتحش الكاميرا | صلاحية الكاميرا مش مضافة | تأكد من `android.permission.CAMERA` في AndroidManifest و`NSCameraUsageDescription` في Info.plist |
| التحسين الأونلاين بياخد وقت طويل | الموديل على Replicate بياخد وقت معالجة (خصوصًا أول مرة/cold start) | ده طبيعي، فيه timeout داخلي (90 ثانية) وبعدها بيرجع للـ fallback المحلي تلقائيًا |
| الأيقونة مش بتظهر بعد التغيير | الكاش القديم للـ launcher | امسح التطبيق وأعد التثبيت، أو `flutter clean` قبل البناء |
| Crash عند فتح الكاميرا على أندرويد | صلاحية مش متطلوبة وقت التشغيل | الكود بيطلب `Permission.camera.request()` قبل الفتح — تأكد إنها مش مرفوضة من إعدادات النظام يدويًا |

---

## 7) هيكل المشروع

```
lib/
  core/constants.dart              # جداول القوة حسب جودة الصورة + إعدادات المستخدم
  models/image_analysis_result.dart
  services/
    api_key_store.dart             # تخزين مفتاح Replicate محليًا
    image_analysis_service.dart    # تحليل + تصنيف الجودة (محلي)
    face_protection_service.dart   # كشف وجوه on-device + فحص تشابه
    enhancement_service.dart       # denoise/sharpen/fallback upscale (Dart خالص)
    remote_enhancement_service.dart # Super-Resolution أونلاين عبر Replicate
    blend_service.dart             # Confidence blending مع الأصل
    enhancement_pipeline.dart      # الأوركستريتور — الجزء التقيل شغال جوه compute()/Isolate
  screens/
    home_screen.dart               # Home Screen: اختر صورة / التقط صورة / إعدادات
    processing_screen.dart
    result_screen.dart
  widgets/before_after_slider.dart
assets/icon/
  icon.png                         # الأيقونة الأساسية (1024×1024)
  icon_foreground.png              # طبقة الـ Adaptive Icon (أندرويد)
```
