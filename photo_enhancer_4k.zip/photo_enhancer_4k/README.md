# 4K Photo Enhancer — تطبيق موبايل يعمل بالكامل Offline

تطبيق Flutter يطبّق الـ Master Prompt المرفق: تحسين الصورة لجودة قريبة من
4K مع الحفاظ التام على الهوية والملامح والخلفية والألوان — **بدون أي اتصال
إنترنت وبدون أي API خارجي**. كل المعالجة (تحليل، كشف وجوه، تكبير بالذكاء
الاصطناعي، دمج) شغالة محليًا على الجهاز.

---

## 1) فك الضغط وتجهيز المشروع

```bash
unzip photo_enhancer_4k.zip -d photo_enhancer_4k
cd photo_enhancer_4k

# المجلد ده فيه lib/ و pubspec.yaml و assets/ بس — من غير android/ و ios/
# لازم تولّدهم بأمر واحد (بيتفادى مشاكل توافق الـ SDK/Gradle القديمة):
flutter create .
```

بعد الأمر ده هتلاقي مجلدي `android/` و `ios/` اتضافوا تلقائيًا بإعدادات
متوافقة مع نسخة Flutter عندك — **متنقلش** مجلدات android/ios من مشروع تاني
لمشروع تاني، ده أشهر سبب لأخطاء الـ build الغريبة.

---

## 2) ضيف صلاحيات الوصول للصور

- **Android:** انسخ محتوى `platform_config/AndroidManifest_additions.xml`
  جوه `android/app/src/main/AndroidManifest.xml`.
- **iOS:** انسخ محتوى `platform_config/Info_plist_additions.xml`
  جوه `ios/Runner/Info.plist`.

---

## 3) جهّز موديل الـ Super-Resolution (خطوة إلزامية للـ Offline enhancement)

اقرأ `assets/models/README_MODEL.txt` بالتفصيل. باختصار:

1. حمّل/حوّل موديل Super-Resolution بصيغة `.tflite` (زي Real-ESRGAN x4).
2. حطه في `assets/models/realesrgan_x4.tflite`.
3. في `pubspec.yaml`، شيل التعليق من سطر الموديل تحت `assets:`.

> **مهم:** لو مش حاطط الموديل، التطبيق **مش هيكسر** — هيشتغل بـ fallback
> تكبير تقليدي عالي الجودة (Lanczos/Cubic) بدل الـ AI upscaling الحقيقي،
> وهيظهر تنبيه صغير في شاشة النتيجة يقولك كده.

---

## 4) التثبيت والبناء

```bash
flutter pub get
flutter analyze          # يظهرلك أي أخطاء/تحذيرات قبل ما تبني
flutter run               # تشغيل على جهاز/إيموليتور متوصل
```

### بناء نسخة Release

```bash
# Android (APK)
flutter build apk --release

# Android (App Bundle لرفعه على Play Store)
flutter build appbundle --release

# iOS (محتاج Mac + Xcode)
flutter build ios --release
```

---

## 5) أخطاء شائعة وإزاي تتفاداها (Checklist)

| المشكلة | السبب الشائع | الحل |
|---|---|---|
| `Unable to load asset: assets/models/realesrgan_x4.tflite` | الملف مش موجود فعليًا أو مش متفعّل في pubspec.yaml | تأكد إن السطر مش متعلّق بـ `#` في `pubspec.yaml` وإن الملف موجود فعلاً في المسار |
| Crash عند فتح المعرض على أندرويد 13+ | صلاحيات ناقصة | تأكد من `READ_MEDIA_IMAGES` في AndroidManifest |
| Crash عند الحفظ على iOS | `NSPhotoLibraryAddUsageDescription` ناقصة | ضيفها في Info.plist (موجودة في platform_config) |
| التطبيق بيهنج/يـ freeze أثناء التحسين | المعالجة الثقيلة شغالة على الـ UI isolate | استخدم `Isolate.run()` أو `compute()` لتغليف نداء `EnhancementPipeline.run` لو هتعالج صور كبيرة جدًا (أكبر من ~12 ميجابكسل) |
| OutOfMemory على صور كبيرة جدًا | تحميل الصورة كاملة في الذاكرة زيادة عن اللازم | المعالجة هنا Tile-based أصلاً (128px)، بس لو زودت `tileSize` في `constants.dart` خليه رقم معقول (128–256) مش أكبر |
| خطوط ظاهرة (seams) بين أجزاء الصورة بعد التكبير | الـ tile overlap صغير أو الموديل شكل الإخراج بتاعه مختلف | زوّد `tileOverlap` في `constants.dart`، وتأكد إن `_runModelOnTile` في `enhancement_service.dart` بيطابق input/output shape الموديل الفعلي بتاعك |
| الموديل بيرفض يحمّل (`Interpreter.fromAsset` بيفشل) | الموديل فيه Ops مش مدعومة في TFLite Builtin (محتاج Select TF Ops) | حوّل الموديل بخيار `--target_spec.supported_ops=TFLITE_BUILTINS` فقط، وجرّب quantization (float16/int8) |
| نتيجة التحسين بتغيّر ملامح الوجه بشكل واضح | Face Protection مضبوط على Standard بدل Maximum | ارجع لإعداد Maximum من شاشة الإعدادات — ده اللي بيحدد `faceEnhancementConfidenceCap` في `constants.dart` |
| build.gradle بيرفض minSdkVersion | tflite_flutter / ML Kit محتاجين minSdk 21+ | افتح `android/app/build.gradle` واتأكد `minSdkVersion 21` (يفضّل 23) |
| نسخة package مش متوافقة مع Flutter عندك | نسخة Flutter SDK قديمة عن نسخ الباكدجات في pubspec.yaml | شغّل `flutter --version`، ولو قديمة حدّثها بـ `flutter upgrade`، أو نزّل أرقام النسخ في pubspec.yaml للمتوافق |

---

## 6) هيكل المشروع

```
lib/
  core/constants.dart              # جداول القوة حسب جودة الصورة + إعدادات المستخدم
  models/image_analysis_result.dart
  services/
    image_analysis_service.dart    # Step 2-3: تحليل + تصنيف الجودة
    face_protection_service.dart   # Step 4: كشف وجوه on-device + فحص تشابه
    enhancement_service.dart       # Step 5-8: denoise/sharpen/SR tile-based
    blend_service.dart             # Step 9-10: Confidence blending مع الأصل
    enhancement_pipeline.dart      # الـ orchestrator الكامل (Final Pipeline)
  screens/
    home_screen.dart               # Home Screen + Advanced Settings
    processing_screen.dart         # Processing Screen بنفس رسائل البرومبت
    result_screen.dart             # Before/After + Save/Share/Enhance Again/New
  widgets/before_after_slider.dart
```

كل ملف بيقابل خطوة معينة من الـ "Final Pipeline" المذكورة في البرومبت
الأصلي، عشان لو عايز تعدّل سلوك خطوة معينة تعرف بالظبط تروح فين.
