# Offline 4K Photo Enhancer

This version uses **Real-ESRGAN `realesr-general-x4v3` exported to ONNX**. The upstream project describes `realesr-general-x4v3` as a tiny general-scene model designed to use much less memory and time than the larger Real-ESRGAN models. The ONNX export used here is about 4.9 MB and accepts dynamic NCHW RGB float32 input with 4x output. 

The Flutter app runs the model locally with ONNX Runtime, uses overlapping tiles to reduce RAM pressure, and tries the available Android hardware execution providers before falling back to CPU.

## What changed

- Removed `tflite_flutter` entirely.
- Added `onnxruntime_v2` with 16 KB Android support and hardware-provider support.
- Added the Real-ESRGAN general x4v3 ONNX model to the build pipeline.
- Added tiled, overlap-blended inference.
- Added camera capture and gallery selection.
- Added a custom application icon.
- Added real processing progress instead of an endless generic `Upscaling...` state.

## Model download during GitHub build

The repository ZIP stays small. GitHub Actions downloads the open model into `assets/models/` before `flutter pub get`, so the resulting APK contains the model and runs offline after installation.

Model URL:
`https://huggingface.co/CoderViking/realesr-general-x4v3-onnx/resolve/main/realesr-general-x4v3.onnx?download=true`

## Important quality note

This is true AI super-resolution, not resize+sharpen. The general x4v3 model is deliberately smaller than RealESRGAN_x4plus, trading some maximum restoration strength for much lower memory use and faster mobile inference. The app then applies conservative natural sharpening and identity-preserving blending.
