# Offline 4K Camera

Android starter project for a fully local camera + photo enhancement app.

## Current implementation
- CameraX capture with `CAPTURE_MODE_MAXIMIZE_QUALITY`
- JPEG quality 100
- Existing image picker
- Automatic processing after capture
- Original is not overwritten
- Saves enhanced copies to `Pictures/Offline4KCamera`
- No cloud image API and no Internet permission

## Important
The included enhancement pipeline is a high-quality adaptive resize baseline, NOT a learned AI super-resolution model. For true AI 4K reconstruction, add a compatible ONNX/TFLite/NCNN super-resolution model and replace `enhanceBitmap()` with tiled accelerated inference.

## GitHub Actions
A workflow can be added to build the project after upload. The project is standard Gradle Android structure.
