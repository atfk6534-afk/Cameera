package com.offline4kcamera

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max

class MainActivity : ComponentActivity() {
    private lateinit var preview: PreviewView
    private lateinit var imageCapture: ImageCapture
    private var cameraProvider: ProcessCameraProvider? = null

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) startCamera() else Toast.makeText(this,"Camera permission is required",Toast.LENGTH_LONG).show()
    }
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { enhanceExisting(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) startCamera()
        else permission.launch(Manifest.permission.CAMERA)
    }

    private fun buildUi() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,20,20,20) }
        preview=PreviewView(this).apply { scaleType=PreviewView.ScaleType.FILL_CENTER }
        box.addView(preview,LinearLayout.LayoutParams(-1,0,1f))
        val row=LinearLayout(this).apply { gravity=Gravity.CENTER }
        val shoot=Button(this).apply { text="📷 Capture"; setOnClickListener{takePhoto()} }
        val pick=Button(this).apply { text="🖼 Enhance"; setOnClickListener{picker.launch("image/*")} }
        row.addView(shoot); row.addView(pick); box.addView(row)
        setContentView(box)
    }

    private fun startCamera() {
        val future=ProcessCameraProvider.getInstance(this)
        future.addListener({
            cameraProvider=future.get()
            val previewUse=Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            imageCapture=ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setJpegQuality(100)
                .build()
            val selector=CameraSelector.DEFAULT_BACK_CAMERA
            cameraProvider?.unbindAll()
            cameraProvider?.bindToLifecycle(this,selector,previewUse,imageCapture)
        },ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val dir=getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
        val file=File(dir,"original_${stamp()}.jpg")
        imageCapture.takePicture(ImageCapture.OutputFileOptions.Builder(file).build(),
            ContextCompat.getMainExecutor(this),object:ImageCapture.OnImageSavedCallback{
                override fun onImageSaved(output:ImageCapture.OutputFileResults) {
                    Toast.makeText(this@MainActivity,"Captured. Enhancing offline…",Toast.LENGTH_SHORT).show()
                    enhanceFile(file)
                }
                override fun onError(e:ImageCaptureException){ Toast.makeText(this@MainActivity,e.message?:"Capture error",Toast.LENGTH_LONG).show() }
            })
    }

    private fun enhanceExisting(uri:Uri) {
        try {
            val input=contentResolver.openInputStream(uri) ?: return
            val file=File(cacheDir,"selected_${stamp()}.jpg")
            FileOutputStream(file).use { input.copyTo(it) }; input.close()
            enhanceFile(file)
        } catch(e:Exception){ Toast.makeText(this,"Could not open image",Toast.LENGTH_LONG).show() }
    }

    /*
     * Offline baseline pipeline.
     * This starter uses high-quality decoding + adaptive 4K resize.
     * Replace enhanceBitmap() with an ONNX/NCNN/TFLite super-resolution
     * model for true learned reconstruction.
     */
    private fun enhanceFile(file:File) {
        Thread {
            try {
                val src=BitmapFactory.decodeFile(file.absolutePath) ?: return@Thread
                val out=enhanceBitmap(src)
                val name="Enhanced_${stamp()}.jpg"
                val values=android.content.ContentValues().apply{
                    put(MediaStore.Images.Media.DISPLAY_NAME,name)
                    put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Offline4KCamera")
                }
                val uri=contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)
                uri?.let { contentResolver.openOutputStream(it)?.use{os->out.compress(Bitmap.CompressFormat.JPEG,100,os)} }
                runOnUiThread { Toast.makeText(this,"Enhanced image saved: $name",Toast.LENGTH_LONG).show() }
                src.recycle(); out.recycle()
            } catch(e:Exception){ runOnUiThread{Toast.makeText(this,"Enhancement failed: ${e.message}",Toast.LENGTH_LONG).show()} }
        }.start()
    }

    private fun enhanceBitmap(src:Bitmap):Bitmap {
        val w=src.width; val h=src.height
        val scale=max(3840f/w,2160f/h)
        val targetW=max(w,(w*scale).toInt())
        val targetH=max(h,(h*scale).toInt())
        return Bitmap.createScaledBitmap(src,targetW,targetH,true)
    }
    private fun stamp()=SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(Date())
}
